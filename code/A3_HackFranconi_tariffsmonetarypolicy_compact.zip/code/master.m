% ==============================================================================
% master.m - one-button replication
% Replication package for "Import Tariffs and the Systematic Response of
% Monetary Policy" by Alessandro Franconi and Lukas Hack
% ------------------------------------------------------------------------------
% Set MATLAB's current folder to the folder of this file (package/code/) and
% run it, or from a terminal:
%     matlab -noFigureWindows -batch "cd('<path>/package/code'); master"
% All paths are relative to this folder. Each stage re-anchors itself, so the
% file can also be run section by section from the editor.
%
%   stage 0  (optional)  delete regenerated results (data/, results_interim/,
%                        results_final/)
%   raw-data mode only:
%   stage 1  MATLAB      matlab/stage00_pca_fredqd.m        FRED-QD components
%   stage 2  Stata       stata/main.do prep                 data construction
%   stage 3  MATLAB      matlab/stage01_estimate_core.m     baseline VARs and
%                                                           counterfactuals
%   stage 4  MATLAB      matlab/stage02_figures_maintext.m  Figures 1-4
%   --- run_mode = "full" only ---
%   stage 5  MATLAB      matlab/stage03_estimate_appendix.m appendix VARs and
%                                                           counterfactuals
%   stage 6  Stata       stata/main.do lp                   local projections
%   stage 7  MATLAB      matlab/stage04_figures_appendix.m  Figures B.1-D.12
%   stage 8  MATLAB      matlab/stage05_tables_appendix.m   Tables D.1-D.2
%   --- both modes ---
%   stage 9  MATLAB      matlab/stage06_numbers_in_text.m   numbers cited in the
%                        text -> results_final/numbers_in_text.txt
% ==============================================================================
%% -------------------------- configuration ------------------------------------
tic
clc; clear all;
set(groot, 'DefaultFigureVisible', 'off');

run_mode      = "full";     % "full": main text + online appendix; "maintext": Figures 1-4 only
data_mode     = "prepared"; % "prepared": use data/vardata_trade_clean.xlsx; "raw": rebuild it
clean_interim = true;       % delete regenerated files before running
resume        = false;      % true: reuse estimates already saved in results_interim/
n_workers     = 8;          % parallel workers (results do not depend on this number)
stata_exec    = '';         % '' = auto-detect; else e.g. '/Applications/StataNow/StataMP.app/Contents/MacOS/stata-mp'

%% -------------------------- stage 0: clean -----------------------------------
assert(exist(fullfile(pwd, 'master.m'), 'file') == 2, ...
    'master: set MATLAB''s current folder to package/code/ first.');
pkgroot = fileparts(pwd);
assert(any(data_mode == ["raw", "prepared"]), ...
    'master: data_mode must be "raw" or "prepared".');
if data_mode == "prepared"
    assert(exist(fullfile(pkgroot, 'data', 'vardata_trade_clean.xlsx'), 'file') == 2, ...
        'master: prepared data not found at data/vardata_trade_clean.xlsx.');
end
if clean_interim && ~resume
    dirs = {fullfile(pkgroot,'results_interim'), ...
            fullfile(pkgroot,'results_final','figures'), fullfile(pkgroot,'results_final','tables')};
    if data_mode == "raw"; dirs{end+1} = fullfile(pkgroot,'data'); end
    for d = dirs
        if exist(d{1}, 'dir')
            c = dir(d{1});
            for k = 1:numel(c)
                if ~c(k).isdir; delete(fullfile(d{1}, c(k).name)); end
            end
            fprintf('master: cleaned %s\n', d{1});
        end
    end
    if exist(fullfile(pkgroot,'results_final','numbers_in_text.txt'), 'file')
        delete(fullfile(pkgroot,'results_final','numbers_in_text.txt'));
    end
end

%% -------------------------- Stata executable ---------------------------------
if exist(fullfile(pwd, 'master.m'), 'file') ~= 2; cd ..; end
if isempty(stata_exec)
    cand = {};
    if ispc
        b = dir('C:\Program Files\Stata*');
        for k = 1:numel(b)
            for exe = {'StataMP-64.exe','StataSE-64.exe','StataBE-64.exe','StataNow-64.exe'}
                cand{end+1} = fullfile(b(k).folder, b(k).name, exe{1}); %#ok<AGROW>
            end
        end
    elseif ismac
        b = dir('/Applications/Stata*');
        for k = 1:numel(b)
            for app = {'StataMP.app/Contents/MacOS/stata-mp', 'StataSE.app/Contents/MacOS/stata-se', 'StataBE.app/Contents/MacOS/stata-be'}
                cand{end+1} = fullfile(b(k).folder, b(k).name, app{1}); %#ok<AGROW>
            end
        end
    else
        cand = {'/usr/local/stata/stata-mp', '/usr/local/stata/stata-se', '/usr/local/stata/stata-be'};
    end
    for k = 1:numel(cand)
        if exist(cand{k}, 'file'); stata_exec = cand{k}; break; end
    end
    if isempty(stata_exec)
        error('master: no Stata executable found - set stata_exec at the top of master.m.');
    end
end
fprintf('master: using Stata at %s\n', stata_exec);

%% -------------------------- stages 1-2: data preparation -------------------
if data_mode == "raw"
    if exist(fullfile(pwd, 'master.m'), 'file') ~= 2; cd ..; end
    cd('matlab');
    stage00_pca_fredqd
    clearvars -except run_mode clean_interim resume n_workers stata_exec
    cd ..

    if exist(fullfile(pwd, 'master.m'), 'file') ~= 2; cd ..; end
    cd('stata');
    if exist(fullfile(pwd, 'main.log'), 'file'); delete('main.log'); end
    if ispc; status = system(['"' stata_exec '" /q /e do main.do prep']);
    else;    status = system(['"' stata_exec '" -q -e do main.do prep']); end
    assert(exist(fullfile(pwd, 'main.log'), 'file') == 2, 'master: Stata produced no main.log.');
    logtxt = fileread('main.log');
    if ~isempty(regexp(logtxt, '\nr\(\d+\);', 'once')) || status ~= 0
        error('master: the Stata data construction reported an error - inspect code/stata/main.log');
    end
    movefile('main.log', fullfile('..', '..', 'results_interim', 'stata_prep.log'));
    fprintf('master: Stata data construction completed without errors.\n');
    cd ..
else
    fprintf('master: using prepared data; skipping FRED-QD and Stata data preparation.\n');
end

%% -------------------------- stage 3: core estimation (MATLAB) ----------------
if exist(fullfile(pwd, 'master.m'), 'file') ~= 2; cd ..; end
cd('matlab');
stage01_estimate_core
clearvars -except run_mode clean_interim resume n_workers stata_exec
cd ..

%% -------------------------- stage 4: main-text figures (MATLAB) --------------
if exist(fullfile(pwd, 'master.m'), 'file') ~= 2; cd ..; end
cd('matlab');
stage02_figures_maintext
clearvars -except run_mode clean_interim resume n_workers stata_exec
cd ..

%% -------------------------- stages 5-8: online appendix ----------------------
if exist(fullfile(pwd, 'master.m'), 'file') ~= 2; cd ..; end
if run_mode == "full"
    cd('matlab');
    stage03_estimate_appendix
    clearvars -except run_mode clean_interim resume n_workers stata_exec
    cd ..

    cd('stata');
    if exist(fullfile(pwd, 'main.log'), 'file'); delete('main.log'); end
    if ispc; status = system(['"' stata_exec '" /q /e do main.do lp']);
    else;    status = system(['"' stata_exec '" -q -e do main.do lp']); end
    assert(exist(fullfile(pwd, 'main.log'), 'file') == 2, 'master: Stata produced no main.log.');
    logtxt = fileread('main.log');
    if ~isempty(regexp(logtxt, '\nr\(\d+\);', 'once')) || status ~= 0
        error('master: the Stata local-projection stage reported an error - inspect code/stata/main.log');
    end
    movefile('main.log', fullfile('..', '..', 'results_interim', 'stata_lp.log'));
    fprintf('master: Stata local projections completed without errors.\n');
    cd ..

    cd('matlab');
    stage04_figures_appendix
    clearvars -except run_mode clean_interim resume n_workers stata_exec
    cd ..

    cd('matlab');
    stage05_tables_appendix
    clearvars -except run_mode clean_interim resume n_workers stata_exec
    cd ..
end

%% -------------------------- stage 9: numbers cited in the text ---------------
if exist(fullfile(pwd, 'master.m'), 'file') ~= 2; cd ..; end
cd('matlab');
stage06_numbers_in_text
clearvars -except run_mode clean_interim resume n_workers stata_exec
cd ..

%% -------------------------- done ---------------------------------------------
if exist(fullfile(pwd, 'master.m'), 'file') ~= 2; cd ..; end
fprintf('master: all stages completed (%s) - final exhibits in ../results_final/.\n', run_mode);
toc
