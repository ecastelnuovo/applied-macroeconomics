* ==============================================================================
* 02_prep_data_var.do - quarterly VAR dataset
* ------------------------------------------------------------------------------
* Builds the quarterly VAR data set from the raw inputs. Feeds every VAR of
* the paper and the local projections.
* Inputs : rawdata/fred/fred_apipull_raw.dta        FRED pull of 2025-09-18
*          rawdata/ludvigson/...                     macro uncertainty (h12)
*          rawdata/mckaywolf/...                     RR and MAR monetary shocks
*          rawdata/hackistrefimeier/mpshocks_him.xlsx  refined RR shock (website)
*          rawdata/wuxia/...                         shadow federal funds rate
*          rawdata/caldaraiacoviello/...             TPU and GPR indices
*          rawdata/schmittgroheuribe/...             trade restrictiveness index
*          rawdata/jarocinski/...                    conventional MP shock u1
*          rawdata/bakerbloomdavis/...               categorical EPU indices
*          rawdata/usitc_dataweb/usitc_customs_value_{all,dutiable}_monthly.xlsx
*          results_interim/fredqd_pca.csv            PC1-PC6 of FRED-QD
*                                                    (code/matlab/stage00_pca_fredqd.m)
*          data/tariffrate_unweighted.dta            01_tariffrate_unweighted.do
* Output : data/vardata_trade_clean.xlsx (1960Q1-2024Q4, variables listed at
*          the end of this file)
* ==============================================================================

*-------------------------------------------------------------------------------
* (1) FRED data (cached pull; variables already renamed in the cache)
*-------------------------------------------------------------------------------
* Series (FRED id -> name): GDPC1 rgdp, PCECC96 rpce, GPDIC1 rinv, GCEC1 rgov,
* IMPGSC1 rimp, EXPGSC1 rexp, UNRATE uer, INDPRO indpro, B235RC1Q027SBEA duties,
* A255RC1Q027SBEA imp_goods, FGRECPT receipttotal, FGSDODNS fdebt_sa,
* W371RG3Q020SBEA totindex_npgood, A652RC1Q027SBEA imp_cons, GDPDEF pgdp,
* CPIAUCSL cpi, CPILFESL cpic, PPIACO ppi_nsa, DFF ffr, GS1 gs1, GDPPOT rgdp_pot,
* MICH infexp_mich1y

use "$pathraw/fred/fred_apipull_raw.dta", clear

keep daten rgdp rpce rinv rgov rimp rexp uer indpro duties imp_goods receipttotal ///
	fdebt_sa totindex_npgood imp_cons pgdp cpi cpic ppi_nsa ffr gs1 rgdp_pot infexp_mich1y

gen 	DATE_Q = yq(year(daten), quarter(daten))
format 	DATE_Q %tq

ds DATE_Q daten, not
collapse (mean) `r(varlist)' , by(DATE_Q)

tsset DATE_Q
save "$pathinterim/fred_clean_quarterly.dta", replace


*-------------------------------------------------------------------------------
* (2) Macro uncertainty (12-month horizon) from S. Ludvigson's website
*-------------------------------------------------------------------------------

import excel "$pathraw/ludvigson/ludvigson_macro_uncertainty_202508.xlsx", clear sheet("Macro Uncertainty") firstrow

rename h12 uncert_macroh12
keep Date uncert_macroh12

gen 		DATE_Q = yq(year(Date),quarter(Date))
format %tq 	DATE_Q
collapse (mean) uncert_* , by(DATE_Q)

tsset DATE_Q
save "$pathinterim/uncertainty_clean_quarterly.dta", replace


*-------------------------------------------------------------------------------
* (3) Monetary shocks from the McKay-Wolf (2023) replication package
*-------------------------------------------------------------------------------

import delimited "$pathraw/mckaywolf/mckaywolf_2023_data.csv" , clear

rename rr_3 		mp_rr
rename mar_svariv	mp_mar

gen year = floor(date)
gen quar = floor((date - year + 0.25) * 4)

gen 	DATE_Q = yq(year, quar)
format 	DATE_Q %tq
keep 	DATE_Q mp_rr mp_mar

tsset DATE_Q 
save "$pathinterim/mckaywolf_shocks.dta", replace


*-------------------------------------------------------------------------------
* (4) Refined Romer-Romer shock from Hack, Istrefi and Meier (2024)
*-------------------------------------------------------------------------------

import excel "$pathraw/hackistrefimeier/mpshocks_him.xlsx", clear sheet("monthly") firstrow

rename HIMshock 	mp_rr_new
keep datemonthly mp_rr_new

gen 	DATE_Q = yq(year(datemonthly), quarter(datemonthly))
format 	DATE_Q %tq

collapse (sum) mp_* , by(DATE_Q)		// meeting-level shocks are summed within the quarter

tsset DATE_Q 
save "$pathinterim/hackistrefimeier_shocks.dta", replace


*-------------------------------------------------------------------------------
* (5) Shadow federal funds rate (Wu and Xia, 2016)
*-------------------------------------------------------------------------------

import excel "$pathraw/wuxia/wuxia_shadow_rate.xls", clear sheet("Sheet1")		// no header: A = month as yyyymm, B = shadow rate

rename (A B) (yyyymm ffr_shadow)

gen 	DATE_Q = yq(floor(yyyymm/100), ceil(mod(yyyymm, 100)/3))
format 	DATE_Q %tq

collapse (mean) ffr_shadow, by(DATE_Q)

tsset DATE_Q
save "$pathinterim/shadowffr_clean_quarterly.dta", replace


*-------------------------------------------------------------------------------
* (6) Trade policy uncertainty (Caldara et al., 2020)
*-------------------------------------------------------------------------------

import excel "$pathraw/caldaraiacoviello/caldara_iacoviello_tpu.xlsx", clear sheet("TPU_QUARTERLY") firstrow 

rename TPUQ ci20_tpu

split DATEQ, gen(date) parse("Q")
destring date*, replace
gen 	DATE_Q = yq(date1, date2)
format 	DATE_Q %tq
keep 	DATE_Q ci20_tpu

tsset DATE_Q
save "$pathinterim/tpu_clean_quarterly.dta", replace


*-------------------------------------------------------------------------------
* (7) Geopolitical risk (Caldara and Iacoviello, 2022)
*-------------------------------------------------------------------------------

import excel "$pathraw/caldaraiacoviello/caldara_iacoviello_gpr.xls", clear  firstrow 

rename GPR 	ci22_gpr

gen 	DATE_Q = yq(year(month), quarter(month))
format 	DATE_Q %tq

collapse ci22_gpr , by(DATE_Q)

tsset DATE_Q
save "$pathinterim/gpr_clean_quarterly.dta", replace


*-------------------------------------------------------------------------------
* (8) Trade restrictiveness index (Schmitt-Grohe and Uribe, 2025)
*-------------------------------------------------------------------------------

import excel "$pathraw/schmittgroheuribe/sgu_2025_trade_restrictiveness.xlsx", clear firstrow 

rename traderestrictivenessindextri sgu25_traderestrict

gen year = floor(date)
gen quar = floor((date - year + 0.25) * 4)
gen 	DATE_Q = yq(year, quar)
format 	DATE_Q %tq
keep 	DATE_Q sgu25_*

tsset DATE_Q
save "$pathinterim/schmittgroheuribe_clean_quarterly.dta", replace


*-------------------------------------------------------------------------------
* (9) Jarocinski (2024) conventional monetary policy shock (u1)
*-------------------------------------------------------------------------------

import delimited "$pathraw/jarocinski/jarocinski_2024_shocks.csv", clear  

replace time = substr(time,1,10)
split time, parse("-") destring

gen DATE_Q = yq(time1, quarter(mdy(time2,time3,time1)))
format %tq DATE_Q

rename u1 mp_j24_u1
keep DATE_Q mp_j24_u1

collapse (sum) mp_* , by(DATE_Q)

save "$pathinterim/jarocinski_shocks_clean_quarterly.dta", replace


*-------------------------------------------------------------------------------
* (10) Principal components of FRED-QD (computed by code/matlab/stage00_pca_fredqd.m)
*-------------------------------------------------------------------------------

import delimited "$pathinterim/fredqd_pca.csv", clear asdouble

gen DATE_Q = yq(year(date(qdate, "YMD")), quarter(date(qdate, "YMD")))
format %tq DATE_Q
drop qdate
rename pc# PC#

save "$pathinterim/fredqd_pca.dta", replace


*-------------------------------------------------------------------------------
* (11) Categorical policy uncertainty indices (Baker, Bloom and Davis, 2016)
*-------------------------------------------------------------------------------

import excel "$pathraw/bakerbloomdavis/bbd_categorical_epu.xlsx", clear firstrow 

foreach v in EconomicPolicyUncertainty Monetarypolicy FiscalPolicyTaxesORSpending Taxes Governmentspending Healthcare Nationalsecurity Entitlementprograms Regulation FinancialRegulation Tradepolicy Sovereigndebtcurrencycri {
	rename  `v' bbd16`v'
}

gen quarter = 4 
replace quarter = 3 if Month < 10
replace quarter = 2 if Month < 7
replace quarter = 1 if Month < 4

drop if _n == _N
destring Year, replace

gen DATE_Q = yq(Year, quarter)
format %tq DATE_Q

collapse (mean) bbd16* , by(DATE_Q)

* Rename to shorten variables names
rename bbd16EconomicPolicyUncertainty bbd16EPU
rename bbd16Monetarypolicy bbd16MonetaryPol 
rename bbd16FiscalPolicyTaxesORSpending bbd16FiscalPol 
rename bbd16Governmentspending bbd16GovSpend 
rename bbd16Entitlementprograms bbd16Entitlementprog 
rename bbd16FinancialRegulation bbd16FinancialReg 
rename bbd16Sovereigndebtcurrencycri bbd16Debtcurrencycri

* Replace zeros to be able to take logs
tsset DATE_Q
foreach v of varlist bbd16* {
	replace `v' = 0.5  * (L.`v' + F.`v') if `v' < 0.0001 
}

save "$pathinterim/bbd_categorical_epu_quarterly.dta", replace


*-------------------------------------------------------------------------------
* (12) Share of dutiable imports in all goods imports (USITC DataWeb)
*-------------------------------------------------------------------------------
* Quarterly sums of the monthly customs value of all imports for consumption
* and of dutiable items; their ratio, averaged over the baseline sample, scales
* goods imports in the trade-weighted tariff rate below.

foreach f in all dutiable {
	if "`f'" == "all" 		local sheet "Query Results"
	if "`f'" == "dutiable" 	local sheet "Customs Value"
	import excel "$pathraw/usitc_dataweb/usitc_customs_value_`f'_monthly.xlsx", clear sheet("`sheet'") cellrange(A3) firstrow
	keep if DataType == "Customs Value"
	rename (January February March April May June July August September October November December) (value1 value2 value3 value4 value5 value6 value7 value8 value9 value10 value11 value12)
	keep Year value*
	foreach v of varlist value* {						// months not yet published are empty strings
		cap confirm string variable `v'
		if !_rc destring `v', replace
	}
	reshape long value, i(Year) j(Month)
	gen 	DATE_Q = yq(Year, ceil(Month/3))
	format 	DATE_Q %tq
	collapse (sum) value , by(DATE_Q)
	rename value customsvalue_`f'
	tempfile cv_`f'
	save `cv_`f'', replace
}
use `cv_all', clear
merge 1:1 DATE_Q using `cv_dutiable', nogen
gen double coverageratio = customsvalue_dutiable / customsvalue_all
su coverageratio if DATE_Q >= yq(1990,1) & DATE_Q <= yq(2024,4)
global dutiableimportshare = `r(mean)'
di $dutiableimportshare 


*-------------------------------------------------------------------------------
* (13) Merge all data sources and compute additional derived variables
*-------------------------------------------------------------------------------

use "$pathinterim/fred_clean_quarterly.dta", clear
merge 1:1 DATE_Q using "$pathinterim/uncertainty_clean_quarterly.dta" , nogen
merge 1:1 DATE_Q using "$pathinterim/mckaywolf_shocks.dta" , nogen
merge 1:1 DATE_Q using "$pathinterim/hackistrefimeier_shocks.dta" , nogen
merge 1:1 DATE_Q using "$pathinterim/shadowffr_clean_quarterly.dta" , nogen
merge 1:1 DATE_Q using "$pathinterim/tpu_clean_quarterly.dta" , nogen
merge 1:1 DATE_Q using "$pathinterim/gpr_clean_quarterly.dta" , nogen
merge 1:1 DATE_Q using "$pathinterim/schmittgroheuribe_clean_quarterly.dta" , nogen
merge 1:1 DATE_Q using "$pathdata/tariffrate_unweighted.dta" , nogen
merge 1:1 DATE_Q using "$pathinterim/jarocinski_shocks_clean_quarterly.dta" , nogen
merge 1:1 DATE_Q using "$pathinterim/fredqd_pca.dta", nogen
merge 1:1 DATE_Q using "$pathinterim/bbd_categorical_epu_quarterly.dta", nogen

* Sample selection
keep if DATE_Q >= yq(1960,1) & DATE_Q <= yq(2024,4)

* Derived variables
tsset DATE_Q

gen rimp_cons   = imp_cons / pgdp
gen tariffrate  = duties / (imp_goods * $dutiableimportshare ) * 100
gen outputgap   = (rgdp / rgdp_pot - 1) * 100 // output gap as percentage deviation from potential output
gen rduties 	= duties / pgdp
gen receipttotal_nd = receipttotal - duties 
gen rreceipttotal_nd = receipttotal_nd / pgdp 
gen rfdebt_sa	= fdebt_sa / pgdp 
gen tradebal 	= rexp - rimp 
gen tradebalgdp = tradebal / rgdp  * 100

* Shadow rate: the Wu-Xia series ends in 2023Q2; afterwards the effective federal funds rate
replace ffr_shadow = ffr if missing(ffr_shadow) & DATE_Q > yq(2023,2)

* Set all missing values to zero 
ds DATE_Q , not
foreach v of varlist `r(varlist)' {
	replace `v' = 0 if `v' == .
}

* Logged and yoy growth rates of variables 
local var_trans rgdp rpce rinv rgov rimp rexp cpi cpic ppi_nsa uncert_macroh12 rduties rreceipttotal_nd rfdebt_sa totindex_npgood tariffrate_nw tariffrate sgu25_traderestrict indpro rimp_cons ci20_tpu ci22_gpr bbd16*

foreach v of varlist `var_trans' {
	gen ln_`v' = log(`v') * 100 
	gen gr_`v' = ln_`v' - L4.ln_`v'
}

* C19 dummy (2020Q1-2021Q4)
gen c19dummy21q4 = DATE_Q >= yq(2020,1) & DATE_Q <= yq(2021, 4)

order *, alpha
order DATE_Q

* Normalize alternative tariff rate measures to have the same variance for the baseline sample 
su tariffrate if DATE_Q >= yq(1990,1) & DATE_Q <= yq(2024,4)
local sdbase = `r(sd)'
su sgu25_traderestrict if DATE_Q >= yq(1990,1) & DATE_Q <= yq(2024,4)
replace sgu25_traderestrict = sgu25_traderestrict / `r(sd)' * `sdbase'
su tariffrate_nw if DATE_Q >= yq(1990,1) & DATE_Q <= yq(2024,4)
replace tariffrate_nw = tariffrate_nw / `r(sd)' * `sdbase'


* Narrative tariff events (Table D.3): quarters with identified tariff policy changes
cap gen tariffnarr_dummyAF = 0

replace tariffnarr_dummyAF = 1 if inlist(DATE_Q, ///
    yq(1994,1), ///  /* NAFTA entry into force */
    yq(1995,1), ///  /* WTO effective */
    yq(1996,2), ///  /* US-Canada SLA I */
    yq(1997,3), ///  /* WTO ITA I */
	yq(2000,2), ///  /* Trade & Development Act (AGOA/CBTPA) */
	yq(2002,1), ///  /* Bush steel safeguard */
	yq(2003,4), ///  /* Early removal of Bush steel tariffs */
    yq(2006,4), ///  /* US-Canada SLA II */
    yq(2016,3), ///  /* WTO ITA II */
	yq(2018,1), ///  /* US tariffs on solar panels/washing machines & steel/aluminum */
	yq(2018,2), ///  /* US tariffs on major partners */
    yq(2018,3), ///  /* US-China tariffs war 1/3 */
	yq(2018,4), ///  /* US-China tariffs war 2/3 */
    yq(2019,1)), /// /* US-China tariffs war 3/3 */

cap gen tariffnarr_shock = tariffnarr_dummyAF * d.tariffrate


* Alternative tariff rate with the Nixon (1971Q3-Q4) and Ford (1975) tariff spikes smoothed out:
* each event quarter is replaced by the mean of the last pre-event and the first post-event quarter
gen dummy_nixon3 = DATE_Q == yq(1971,3)
gen dummy_nixon4 = DATE_Q == yq(1971,4)
gen dummy_ford1  = DATE_Q == yq(1975,1)
gen dummy_ford2  = DATE_Q == yq(1975,2)
gen dummy_ford3  = DATE_Q == yq(1975,3)
gen dummy_ford4  = DATE_Q == yq(1975,4)

gen tariffrate_nf = tariffrate
replace tariffrate_nf = 0.5*(L.tariffrate + F2.tariffrate) if dummy_nixon3 
replace tariffrate_nf = 0.5*(L2.tariffrate + F.tariffrate) if dummy_nixon4 

replace tariffrate_nf = 0.5*(L.tariffrate + F4.tariffrate) if dummy_ford1 
replace tariffrate_nf = 0.5*(L2.tariffrate + F3.tariffrate) if dummy_ford2 
replace tariffrate_nf = 0.5*(L3.tariffrate + F2.tariffrate) if dummy_ford3 
replace tariffrate_nf = 0.5*(L4.tariffrate + F1.tariffrate) if dummy_ford4 


* Export the variables the MATLAB stages read
keep DATE_Q ///
	ln_uncert_macroh12 ln_totindex_npgood gr_cpi ln_rimp ln_rexp ln_rinv ln_rgdp tariffrate ffr ///
	rexp rimp rgdp ///
	tariffnarr_shock PC1 PC2 PC3 PC4 PC5 PC6 ///
	sgu25_traderestrict tariffrate_nw tariffrate_nf tradebalgdp c19dummy21q4 ///
	ln_bbd16* ffr_shadow gs1 gr_ppi_nsa gr_cpic infexp_mich1y ln_indpro outputgap uer ///
	ln_ci20_tpu ln_ci22_gpr ln_rpce ln_rimp_cons ln_rduties ln_rreceipttotal_nd ln_rgov ln_rfdebt_sa ///
	mp_mar mp_rr mp_rr_new mp_j24_u1
order *, alpha
order DATE_Q

export excel "$pathdata/vardata_trade_clean.xlsx" , replace firstrow(var)
