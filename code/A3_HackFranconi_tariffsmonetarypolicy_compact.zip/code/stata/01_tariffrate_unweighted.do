* ==============================================================================
* 01_tariffrate_unweighted.do - unweighted average import tariff rate
* ------------------------------------------------------------------------------
* Unweighted average of the tariff rate over HTS lines and countries, for the
* countries with above-median dutiable imports. Used in Figures D.3 and D.4
* (variable tariffrate_nw).
* Inputs : rawdata/usitc_dataweb/DataWeb-Query-Export_<1989..2024>.xlsx
*          (USITC DataWeb, imports for consumption by HTS line and country,
*          quarterly; sheets "Dutiable Value" and "Calculated Duties")
* Outputs: results_interim/usitc_merged_*.dta (large intermediates)
*          data/tariffrate_unweighted.dta  (DATE_Q, tariffrate_nw; 1989Q1-2024Q4)
* ==============================================================================

* (1) Load and append the yearly exports for each variable separately
foreach v in "Dutiable Value" "Calculated Duties" {

	local varname 	= subinstr("`v'", " ","",.)
	local storename = lower(subinstr("`v'", " ","_",.))

	import excel "$pathraw/usitc_dataweb/DataWeb-Query-Export_1989.xlsx", clear sheet("`v'") firstrow

	drop if DataType != "`v'"
	keep Year Quarter HTSNumber `varname' Country
	gen HTSNumber_str = HTSNumber
	destring HTSNumber `varname', replace

	tempfile temp 
	save `temp' , replace

	forv y = 1990(1)2024 {
		import excel "$pathraw/usitc_dataweb/DataWeb-Query-Export_`y'.xlsx", clear sheet("`v'") firstrow

		drop if DataType != "`v'"
		keep Year Quarter HTSNumber `varname' Country
		gen HTSNumber_str = HTSNumber
		destring HTSNumber `varname', replace

		append using `temp'	
		save `temp' , replace
	}
	save "$pathinterim/usitc_merged_`storename'.dta" , replace
}

* (2) Merge and compute the disaggregated tariff rate
use  "$pathinterim/usitc_merged_calculated_duties.dta", clear
merge 1:1 Year Quarter HTSNumber Country using "$pathinterim/usitc_merged_dutiable_value.dta"
drop _merge

gen 	DATE_Q = yq(Year, Quarter)
format 	DATE_Q %tq

gen float tariffrate = CalculatedDuties / DutiableValue * 100

keep Country DATE_Q HTSNumber* tariffrate CalculatedDuties DutiableValue
order Country DATE_Q HTSNumber* tariffrate CalculatedDuties DutiableValue

save "$pathinterim/usitc_merged_tariff_rate.dta" , replace

* (3) Unweighted average over countries with average dutiable value above the median
replace DutiableValue = . if DutiableValue < 0.0001 // avg conditional on trade
collapse (mean) DutiableValue , by(Country)
rename DutiableValue DutiableValueAvg

qui su DutiableValueAvg , de
drop if DutiableValueAvg < r(p50)

merge 1:m Country using "$pathinterim/usitc_merged_tariff_rate.dta", keep(match) nogen
rename tariffrate tariffrate_nw
collapse (mean) tariffrate_nw , by(DATE_Q)
save "$pathdata/tariffrate_unweighted.dta" , replace
