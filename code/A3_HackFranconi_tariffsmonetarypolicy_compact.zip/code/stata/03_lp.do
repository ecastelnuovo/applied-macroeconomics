* ==============================================================================
* 03_lp.do - local projections of the baseline tariff shock (Figure D.5)
* ------------------------------------------------------------------------------
* Run after the MATLAB core stage wrote results_interim/shock_tariffrate.xlsx.
* Inputs : results_interim/shock_tariffrate.xlsx (structural tariff shock at the OLS
*          estimates of the baseline VAR, 1991Q1-2024Q4, one column, no header)
*          data/vardata_trade_clean.xlsx
* Output : results_interim/lp_results.csv (h, b_*, up_*, dn_*, up90_*, dn90_*; up90/dn90 = b +/- 1.645 s.e.)
* ==============================================================================

**** LOAD SHOCK
import excel "$pathinterim/shock_tariffrate.xlsx", ///
    sheet("Sheet1") clear							// no header row

rename A tariffshock
	
* shock file begins in 1991q1
gen qdate = q(1991q1) + _n-1
format qdate %tq

tempfile shock
save `shock', replace

**** LOAD MAIN DATASET
import excel "$pathdata/vardata_trade_clean.xlsx", ///
    sheet("Sheet1") firstrow clear

**** Create quarterly date (the dataset starts in 1960q1)
gen qdate = q(1960q1) + _n-1
format qdate %tq
tsset qdate, q

**** MERGE SHOCK INTO MAIN DATA
merge 1:1 qdate using `shock', nogenerate

**** ESTIMATE LP
local hor  21
local p    4
local shock tariffshock

drop if qdate < tq(1990q1)

gen h=_n-1
gen t1 = _n

foreach y in tariffrate ln_uncert_macroh12 ln_totindex_npgood gr_cpi ln_rimp ln_rexp ln_rinv ln_rgdp ffr tradebalgdp {

*** Estimate the response of x to a shock in y with LP
*** Generate empty vector to fill with estimates
cap gen b_`y' 		= .
cap gen up_`y'		= .
cap gen dn_`y'		= .
cap gen up90_`y'	= .
cap gen dn90_`y'	= .

forvalues i = 0/`hor'{
	
	qui ivreg2 f`i'.`y' `shock' l(1/`p').`y' t1 l(1/`p').`shock', robust bw(auto) 
	replace b_`y' 	 = _b[`shock'] if _n == `i' + 1					// row with h = i
	replace up_`y' 	 = _b[`shock'] + _se[`shock'] if _n == `i' + 1
	replace dn_`y'   = _b[`shock'] - _se[`shock'] if _n == `i' + 1
	replace up90_`y' = _b[`shock'] + 1.645*_se[`shock'] if _n == `i' + 1		// 90% band
	replace dn90_`y' = _b[`shock'] - 1.645*_se[`shock'] if _n == `i' + 1

}

}

local hmax 20

* Keep only horizons up to hmax and the IRF results
drop if h > `hmax'
keep h b_* up_* dn_* up90_* dn90_*

export delimited using "$pathinterim/lp_results.csv", replace
