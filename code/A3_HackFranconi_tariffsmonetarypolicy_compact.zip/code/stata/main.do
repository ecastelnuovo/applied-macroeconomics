* ==============================================================================
* MASTER FILE - Stata
* Replication package for "Import Tariffs and the Systematic Response of
* Monetary Policy" by Alessandro Franconi and Lukas Hack
* ------------------------------------------------------------------------------
* Launched in batch mode by code/master.m from this folder (package/code/stata):
*     stata-mp -q -e do main.do prep   data construction (01, 02)
*     stata-mp -q -e do main.do lp     local projections (03), after the
*                                      MATLAB core stage exported the shock
* All paths are relative to this folder. User-contributed commands (ivreg2,
* ranktest, livreg2) are shipped in ./ado and nothing is installed at run time.
* ==============================================================================

args stage
if "`stage'" == "" local stage "prep"

clear all
set more off
capture log close
set varabbrev off
version 17

* Use ONLY the ado files shipped with this package
sysdir set PLUS "`c(pwd)'/ado/plus/"
sysdir set PERSONAL "`c(pwd)'/ado/personal/"
mata: mata mlib index

global pathraw     "../../rawdata"
global pathdata    "../../data"
global pathinterim "../../results_interim"
cap mkdir "$pathdata"
cap mkdir "$pathinterim"

if "`stage'" == "prep" {
    do "01_tariffrate_unweighted.do"
    do "02_prep_data_var.do"
}
else if "`stage'" == "lp" {
    do "03_lp.do"
}
else {
    di as error "main.do: unknown stage `stage' (use prep or lp)"
    error 198
}
