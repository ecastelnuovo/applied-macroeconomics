% setupfigs.m - figure appearance shared by all figure scripts (interpreters,
% font sizes, colours, common axis settings)
addpath('auxfiles/');
set(groot, 'DefaultFigureVisible', 'off');

% Set text interpreter for figures to latex
set(groot,'defaulttextinterpreter','latex');
set(groot,'defaultLegendInterpreter','latex');
set(groot,'defaultAxesTickLabelInterpreter','latex');  
set(groot,'defaultAxesFontSize',15)
set(groot,'defaultLegendFontSize',15)
set(groot,'defaultAxesLabelFontSizeMultiplier',1)   % axis labels at the tick-label size

% Define colors 
col_blue = [0.12156862745098039, 0.4666666666666667, 0.7058823529411765];
col_orange = [1.0, 0.4980392156862745, 0.054901960784313725];
col_green = [0.17254901960784313, 0.6274509803921569, 0.17254901960784313];
col_red = [0.8392156862745098, 0.15294117647058825, 0.1568627450980392];
col_red_light = [0.8392156862745098, 0.15294117647058825, 0.1568627450980392, .5];
col_gray_light = [0.65, 0.65, 0.65];
col_gray_llight = [0.85, 0.85, 0.85];
col_gray = [0.4, 0.4, 0.4];
col_dgray = [0.3, 0.3, 0.3];
col_black = [0, 0, 0];

% Common parameters across IRFs
xincrement  = 4;
H           = 20;
xname       = 'Quarters';

% Labels and number of credibility bands
ylab_percent    = "percent";
ylab_ppoint     = "percentage points";
