% stage01_estimate_core.m - baseline tariff VAR, baseline monetary VAR, baseline counterfactuals
% ------------------------------------------------------------------------------
% Baseline tariff VAR, baseline monetary VAR (MAR and RR shocks, 1969Q1-2014Q4)
% and the three baseline counterfactuals. Runs in both modes.
% Feeds Figures 1-4 and, through the saved structures, every appendix exhibit.
% Input : data/vardata_trade_clean.xlsx
% Output: results_interim/var_base.mat, var_basemp.mat, cf_stab{ffr,inf,gdp}_base.mat
%         results_interim/shock_tariffrate.{xlsx,mat} (structural tariff shock,
%         1991Q1-2024Q4; read by code/stata/03_lp.do and 05_tables_appendix.m)
% ------------------------------------------------------------------------------
clearvars -except run_mode resume n_workers stata_exec
pkg_settings;
tData = readtable(char(pathData + "vardata_trade_clean.xlsx"));
if isempty(gcp('nocreate')); parpool('local', n_workers); end

%% Tariff VAR: Baseline
if havevar("base")
    sTariff = loadvar("base");
else
    t0 = tic;
    sTariff         = sDefault;
    sTariff.name    = "base";
    sTariff = fVARestimation(sTariff, tData);
    sTariff = add_tradebalance(sTariff, tData);

    % Structural tariff shock at the OLS estimates of the reduced-form parameters (the posterior mean under the flat prior)
    VARshocks = sTariff.VARshocks;
    writematrix(sTariff.VARshocks, char(pathResults + "shock_tariffrate.xlsx"), 'Sheet', 1);
    save(char(pathResults + "shock_tariffrate.mat"), 'VARshocks');

    sTariff = rmfield(sTariff, 'arrIRFdist');      % posterior draws not needed downstream
    savevar("base", sTariff);
    fprintf('stage01_estimate_core: baseline tariff VAR done in %.0f s\n', toc(t0));
end

%% Monetary VAR: MAR x RR 1969Q1-2014Q4 (internal instruments, McKay and Wolf, 2023)
if havevar("basemp")
    sMP = loadvar("basemp");
else
    t0 = tic;
    sMP                 = sDefault;
    sMP.name            = "basemp";
    sMP.idx_ffr         = find(strcmp(sDefault.vVariables, "ffr")); % find position of "ffr" 
    sMP.shockname       = ["mp_mar" "mp_rr" ];
    sMP.vVariables      = [sMP.shockname(1), sDefault.vVariables(1:sMP.idx_ffr-1), sMP.shockname(2), sDefault.vVariables(sMP.idx_ffr:end)];
    sMP.vShockPos       = [find(strcmp(sMP.vVariables, sMP.shockname(1))), find(strcmp(sMP.vVariables, sMP.shockname(2)))];
    sMP.vSample         = ["1969-01-01", "2014-10-01"];
    sMP.missingzero     = true;
    sMP.scalingfactor   = ""; % empty: no normalisation needed

    sMP = fVARestimation(sMP, tData);
    sMP = add_tradebalance(sMP, tData);
    savevar("basemp", sMP);                        % keeps the posterior draws (counterfactuals)
    fprintf('stage01_estimate_core: baseline monetary VAR done in %.0f s\n', toc(t0));
end

%% Cfct: Baseline (no FFR response, strict inflation stabilization, strict output stabilization)
cfs = {"ffr", "stabffr_base"; "gr_cpi", "stabinf_base"; "ln_rgdp", "stabgdp_base"};
for k = 1:size(cfs, 1)
    if havecf(cfs{k,2}); continue; end
    sCF         = sDefaultcf;
    sCF.target  = cfs{k,1};
    sCF.name    = cfs{k,2};
    sCF = fVARcfct(sTariff, sMP, sCF);
    sCF = rmfield(sCF, 'arrIRFdist');
    savecf(cfs{k,2}, sCF);
end
fprintf('stage01_estimate_core: baseline counterfactuals saved\n');
