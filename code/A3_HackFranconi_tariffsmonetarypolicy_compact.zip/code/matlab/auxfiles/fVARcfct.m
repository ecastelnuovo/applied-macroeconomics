function sCF = fVARcfct(sBL,sMP,sCF)
% This function takes structures of an estimated BL IRF, a corresponding 
% structure of policy IRFs and a setup structure for the counterfactual and
% delivers counterfactual IRFs.


% Obtain all variables that appear in both results structures
[sCF.vVariables, id_bl, id_mp] = intersect(sBL.vVariables, sMP.vVariables,'stable');

% Obtain position of target variable 
id_bl_target = find(strcmp(sBL.vVariables, sCF.target));  
id_mp_target = find(strcmp(sMP.vVariables, sCF.target));  

% Obtain maximum response horizon
H = min(size(sBL.arrIRF,2), size(sMP.arrIRF,2));

% Check that BL structure has only IRFs to single shock 
if ndims(sBL.arrIRF) > 3 
    error("More than one impulse response in baseline IRF array")
end

% Extract baseline median IRFs for all variables 
arrIRFBL = sBL.arrIRF(:,1:H,ceil(size(sBL.arrIRF,3)/2))';

% Assign objects for least squares minimization. 
Y = arrIRFBL(:,id_bl_target);
X = permute(squeeze(sMP.arrIRFdist(id_mp_target,1:H,:,:)), [1 3 2]);


% Compute weighting matrix
if sCF.weighting  == "uniform"
    vWeight = ones(1,H);
elseif sCF.weighting == "linear"
    vWeight = flip(1:H);
elseif sCF.weighting == "quadratic"
    vWeight = flip(1:H).^2; 
end
mWeight = diag((vWeight)/sum(vWeight));


% Initialize variables for looping over draws
ndraw   = size(sMP.arrIRFdist, 3);
nvar    = size(sCF.vVariables, 2);
nshocks = size(sMP.arrIRF, 4);

sCF.mWeightdist = NaN(nshocks,ndraw);
sCF.arrIRFdist = NaN(H,nvar,ndraw);

% Loop over policy shock draws and compute weights conditional on each draw
for kk = 1:ndraw
    % Compute weights for current draw
    sCF.mWeightdist(:,kk) = - (X(:,:,kk)' * mWeight * X(:,:,kk)) \ (X(:,:,kk)' * mWeight * Y);

    % Compute IRF for current draw given the weights
    for qq = 1:nvar 
        if nshocks > 1
            sCF.arrIRFdist(:,qq,kk) = arrIRFBL(:,id_bl(qq)) + squeeze(sMP.arrIRFdist(id_mp(qq),1:H,kk,:)) * sCF.mWeightdist(:,kk);
        else % Catch error for one-shock case because the implict transposition (via matrix multiplication) does not operate in the scalar case
            sCF.arrIRFdist(:,qq,kk) = arrIRFBL(:,id_bl(qq)) + squeeze(sMP.arrIRFdist(id_mp(qq),1:H,kk,:))' * sCF.mWeightdist(:,kk);
        end
    end
end

% Select percentiles and harmonize dimensions
sCF.arrIRF = permute(prctile(sCF.arrIRFdist,sCF.pct,3), [2 1 3]); 
sCF.arrIRFdist = permute(sCF.arrIRFdist, [2 1 3]);



end