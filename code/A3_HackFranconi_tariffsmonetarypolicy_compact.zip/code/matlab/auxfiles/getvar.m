function [ylab varname] = getvar(str)
% getvar - y-axis label (ylab) and display name (varname) of a VAR variable

varname = "";

switch str
    case "ln_uncert_macroh12"
        ylab = "percent";
        varname = "Macro uncertainty";
    case "ln_totindex_npgood"
        ylab = "percent";
        varname = "Terms of trade";
    case "gr_cpi"
        ylab = "percentage points";
        varname = "CPI inflation";
    case "ln_rimp"
        ylab = "percent";
        varname = "Real imports";
    case "ln_rexp"
        ylab = "percent";
        varname = "Real exports";
    case "ln_rinv"
        ylab = "percent";
        varname = "Real private investment";
    case "ln_rgdp"
        ylab = "percent";
        varname = "Real GDP";
    case "tradebalgdp"
        ylab = "percentage points";
        varname = "Tradebalance to GDP";
    case "tariffrate"
        ylab = "percentage points";
        varname = "Import tariff rate";
    case "sgu25_traderestrict"
        ylab = "percentage points";
        varname = "Import tariff rate";
    case "tariffrate_nw"
        ylab = "percentage points";
        varname = "Import tariff rate";
    case "tariffrate_nf"
        ylab = "percentage points";
        varname = "Import tariff rate";
    case "ffr"
        ylab = "percentage points";
        varname = "Federal funds rate";
    case "tradebalance"
        ylab = "percentage points";
        varname = "Trade balance";
    case "uer"
        ylab = "percentage points";
        varname = "Unemployment rate";
    case "gs1"
        ylab = "percentage points";
        varname = "One-year treasury yield";
    case "ffr_shadow"
        ylab = "percentage points";
        varname = "Shadow federal funds rate";
    case "infexp_mich1y"
        ylab = "percentage points";
        varname = "Inflation expectations";
    case "gr_ppi_nsa"
        ylab = "percentage points";
        varname = "PPI inflation";
    case "gr_IIPg"
        ylab = "percentage points";
        varname = "Price growth of industrial supplies";
    case "gr_IIPdg"
        ylab = "percentage points";
        varname = "Price growth of industrial supplies (DG)";
    case "gr_cpic"
        ylab = "percentage points";
        varname = "CPI core inflation";
    case "ln_ci20_tpu"
        ylab = "percent";
        varname = "Trade policy uncertainty";
    case "ln_indpro"
        ylab = "percent";
        varname = "Industrial production";
    case "outputgap"
        ylab = "percentage points";
        varname = "Output gap";
    case "ln_rduties"
        ylab = "percent";
        varname = "Real customs duties";
    case "ln_rfdebt_sa"
        ylab = "percent";
        varname = "Real gov't debt";
    case "ln_rgov"
        ylab = "percent";
        varname = "Real gov't spending";
    case "ln_rreceipttotal_nd"
        ylab = "percent";
        varname = "Real gov't receipts";
    case "ln_ci22_gpr"
        ylab = "percent";
        varname = "Geopolitical risk";
    case "ln_rpce"
        ylab = "percent";
        varname = "Real consumption";
    case "ln_rimp_cons"
        ylab = "percent";
        varname = "Real consumption imports";     
    case "mp_rr"
        ylab = "percent";
        varname = "RR04 shock";   
    case "mp_mar"
        ylab = "percentage points";
        varname = "MAR21 shock";   
    case "mp_j24_u1"
        ylab = "percentage points";
        varname = "J24 shock (conventional)";   
    case "mp_rr_new"
        ylab = "percentage points";
        varname = "RR04 shock (refined)";
    case "PC1"
        ylab = "";
        varname = "PC1";
    case "PC2"
        ylab = "";
        varname = "PC2";
    otherwise
        ylab = "percent";   % fallback if str is not in the list
        varname = str;  
end



end