%% EXTRACT THE PRINCIPAL COMPONENTS FROM THE FRED-QD DATA SET

VarNames=dataFREDMD.Properties.VariableNames(1,2:end);
tcode=dataFREDMD{2,2:end};
rawdata=dataFREDMD{2:end,2:end};

timestr = dataFREDMD{2:end,1};
timestr_dates = datetime(timestr,'InputFormat','MM/dd/yyyy','Format','MMM-dd-yyyy'); % the 'Format' just controls display

%% setting time frame of estimation
T0 = find(day(timestr_dates)==01 & month(timestr_dates)==startmonth &  year(timestr_dates)==startyear);         % first quarter of the estimation window
Tend = find(day(timestr_dates)==01 & month(timestr_dates)==endmonth &  year(timestr_dates)==endyear);       % last quarter of the estimation window

bigdata=rawdata(T0:Tend,:);
timestr_data = timestr_dates(T0:Tend);


%% looking for NaN and deleting series with strange trasformation


find_NaN = isnan(bigdata);
find_NaN = sum(find_NaN,1);
find_NaN(find(tcode==7))=1;

bigdata(:,find_NaN>0) = [];
VarNames(find_NaN>0) = [];
tcode(find_NaN>0) = [];


%% data transformation

%%% data in levels - trasforming series
[T,N] = size(bigdata);

data_trsfm = NaN(size(bigdata));
for j = 1:N
    xj = bigdata(:, j);
    switch tcode(j)
        case 1
            data_trsfm(:, j) = xj;
        case 2
            data_trsfm(2:end, j) = diff(xj);
        case 3
            data_trsfm(3:end, j) = diff(diff(xj));
        case 4
            data_trsfm(:, j) = log(xj);
        case 5
            data_trsfm(2:end, j) = diff(log(xj)) * 100;
        case 6
            data_trsfm(3:end, j) = diff(diff(log(xj))) * 100;
        case 7
            data_trsfm(2:end, j) = (xj(2:end) ./ xj(1:end-1) - 1) * 100;
        otherwise
            warning('Unrecognized tcode %d for variable %d', tcode(j), j);
    end
end

    
cd = zeros(1,size(data_trsfm,2));     
for i=1:N
    if tcode(i)==1||tcode(i)==4||tcode(i)==2||tcode(i)==5  ||tcode(i)==6
        cd(i)=0;
    elseif tcode(i)==3||tcode(i)==7
        cd(i)=1;
    end
end

data_trsfm(1:2,:) = [];


data_std = zscore(data_trsfm); % standardize dataset
% Perform PCA
[coeff, score, latent, tsquared, explained, mu] = pca(data_std);

[rhat1, rhat2] = ABC_crit(data_std, 10, floor(size(data_std,2)/10), 3, 0);