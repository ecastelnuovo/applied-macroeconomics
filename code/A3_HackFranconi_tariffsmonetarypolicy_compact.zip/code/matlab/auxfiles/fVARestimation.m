function s = fVARestimation(s, tData)
% Takes VAR structure and data table as input, loads the data, and estimates
% the specified VAR model. Estimation results are appended to the input
% structure


%%% Data preparation

% Time index
idstart = find(tData.(s.datevar) == datetime(s.vSample(1)));
idend   = find(tData.(s.datevar) == datetime(s.vSample(2)));

% Data to matrix and set missings to zero if specified
mData   = tData{idstart:idend,s.vVariables};
if isfield(s, 'missingzero') && s.missingzero 
    mData(isnan(mData)) = zeros(size(mData(isnan(mData)))); 
end

% Load structure variable to workspace as desired
lags            = s.lags; 
boDeterministic = isfield(s,'detpolynorder') && s.detpolynorder >= 0;
if isfield(s, 'Exovar')
    boExovar = sum(~(s.Exovar == ""));
else
    boExovar = 0; 
end
if boDeterministic
    nex = s.detpolynorder + boExovar + 1; % number of deterministic variables
else 
    nex = 0;
end

% Prepare data matrices
[nobs, nvar] = size(mData);
Y = mData(lags+1:end,:);
X = nan(nobs-lags,nvar*lags+boDeterministic*nex);

% Add lags
for i = 1:lags
    X(:,(i-1)*nvar+1:i*nvar) = mData(lags-i+1:end-i,:);
end




% Add deterministic variables (centered and scaled time polynomial)
if boDeterministic
    t = (1:(nobs-lags))';                          % raw time index
    z = (t - mean(t)) / std(t);                    % centered & scaled
    for i = 0:s.detpolynorder
        X(:,nvar*lags+i+1) = z.^i;                 % constant + poly(z)
    end
end

if boExovar >= 1
    ExoData = tData{idstart:idend,s.Exovar};
    X(:, (end-boExovar+1):end) = ExoData(lags+1:end,:);  % exogenous regressor(s)
end

%%% -------------------------
%%% Estimation
%%% -------------------------

if strcmp(s.estimator.name, "bvar_inversewishart") 

    % Shorthands
    T           = nobs-lags;
    p           = lags;
    n           = nvar;
    nd          = s.estimator.nd;
    bburn       = s.estimator.burn;
    H           = s.estimator.H;
    vShockPos   = s.vShockPos;

    % Companion-form matrices
    J = [eye(n); repmat(zeros(n),p-1,1)];
    F = zeros(n*p,n*p);
    I = eye(n);
    for i=1:p-1
        F(i*n+1:(i+1)*n,(i-1)*n+1:i*n) = I;
    end

    B = (X'*X) \ (X'*Y);

    U = Y - X * B;
    Sigmau = U'*U / (T - p*n - 1);
    LC = chol(Sigmau)';
    Omega1 = [LC; zeros((p-1)*n, size(LC,2))];
    A0 = (LC') \ eye(size(LC,1));
    F(1:n,1:n*p) = B(1:n*p,:)';

    nKeep = nd - bburn;
    nShocks = length(s.vShockPos);

    Ltilde = zeros(nKeep, H+1, n, nShocks); % Add one dimension for shocks

    N0 = zeros(size(X',1), size(X,2));
    nnu0 = 0;
    nnuT = T + nnu0;
    NT = N0 + X'*X;
    Bbar0 = B;
    S0 = Sigmau;
    ST = (nnu0/nnuT)*S0 + (T/nnuT)*Sigmau ...
        + (1/nnuT) * ((B - Bbar0)') * N0 * (NT \ eye(n*p+nex)) * (X'*X) * (B - Bbar0);
    STinv = ST \ eye(n);

    if isempty(gcp('nocreate'))
        parpool('local',4);
    end
    sc = parallel.pool.Constant(RandStream('Threefry'));

    parfor iter = 1:nd
        stream = sc.Value;
        stream.Substream = iter;
        RandStream.setGlobalStream(stream);

        R = mvnrnd(zeros(n,1), STinv/nnuT, nnuT)';
        Sigmadraw = (R * R') \ eye(n);
        bbeta = B(:);
        SigmaB = kron(Sigmadraw, NT \ eye(n*p+nex));
        SigmaB = (SigmaB + SigmaB') / 2;
        Bdraw = mvnrnd(bbeta, SigmaB);
        Bdraw = reshape(Bdraw, n*p+nex, n);

        LC = chol(Sigmadraw, 'lower');
        F_temp = F;
        F_temp(1:n,1:n*p) = Bdraw(1:n*p,:)';

        IRF_T = vm_irf(F_temp, J, LC, H+1, n, Omega1);

        for ss = 1:nShocks
            shock_idx = vShockPos(ss);
            Ltilde(iter,:,:,ss) = IRF_T(:,:,shock_idx);
        end

    end

    % Drop burn-in
    Ltilde = Ltilde(bburn+1:end,:,:,:);

    % Select relevant percentiles
    Ltilde_ptile = prctile(Ltilde, s.estimator.pct);

%%%%%%%%%%%%%%%%%%%%%%%%
% Apply scaling factor 

if isnumeric(s.scalingfactor)

    % Normalization by impact and scale
    Ltilde       = Ltilde ./ Ltilde(:,1,s.vShockPos,:) * s.scalingfactor;
    Ltilde_ptile = prctile(Ltilde, s.estimator.pct);   % percentiles of the normalised draws

elseif strcmpi(s.scalingfactor,"unit")

    % Unit normalization by impact
    for iShock = 1:size(Ltilde,4)
        Ltilde(:,:,:,iShock)       = Ltilde(:,:,:,iShock) ./ Ltilde(:,1,s.vShockPos(iShock),iShock);
        Ltilde_ptile(:,:,:,iShock) = Ltilde_ptile(:,:,:,iShock) ./ Ltilde_ptile(:,1,s.vShockPos(iShock),iShock);
    end

end
%%%%%%%%%%%%%%%%%%%%%%%%

    % Augment estimation results
    s.arrIRF        = permute(Ltilde_ptile, [flip(1:3) 4]);
    s.arrIRFdist    = permute(Ltilde, [3 2 1 4]);
    % Structural shocks: Cholesky factor of the OLS covariance applied to the OLS residuals
    % (OLS = posterior mean of the reduced-form parameters under the flat prior)
    s.VCM_new   = U'*U / (T - p*n - 1); 
    LC_new = chol(s.VCM_new, 'lower');
    eps = LC_new \ U';
    s.VARshocks = eps(s.vShockPos,:)';

    %%% Print model summary
    fprintf("----------------------------------------------------------------------\n")
    fprintf("----------------------------------------------------------------------\n")
    fprintf("----------------------------------------------------------------------\n")
    fprintf("Estimation completed successfully\n\n")
    fprintf("Model: " + s.name + "\n")
    fprintf("Variables: " + strjoin(s.vVariables, ", ") + "\n")
    fprintf("Sample: " + datestr(tData{idstart,s.datevar}) + " - " + datestr(tData{idend,s.datevar}) + "\n")
    fprintf("Lags: " + s.lags + "\n")
    fprintf("Shocks: " + strjoin(s.vVariables(s.vShockPos), ", ") + "\n")
    fprintf("Estimator: " + s.estimator.name + "\n")
    fprintf("----------------------------------------------------------------------\n")
    fprintf("----------------------------------------------------------------------\n")
    fprintf("----------------------------------------------------------------------\n")
else 
    error("estimator not implemented")
end 







end