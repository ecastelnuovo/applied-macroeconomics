function s = add_tradebalance(s, tData)
% Take structure with estimation results and add tradebalance as composite
% variable. Use estimation data to compute average exports and imports

% Get estimation sample
idstart = find(tData.(s.datevar) == datetime(s.vSample(1)));
idend   = find(tData.(s.datevar) == datetime(s.vSample(2)));

% Compute trade balance using average imports and exports in the sample
s.arrIRFdist(end+1,:,:,:) = (s.arrIRFdist(find(s.vVariables == "ln_rexp"),:,:,:).*mean(tData.rexp(idstart:idend)) ...
        - s.arrIRFdist(find(s.vVariables == "ln_rimp"),:,:,:).*mean(tData.rimp(idstart:idend))) / mean(tData.rgdp(idstart:idend));
s.arrIRF(end+1,:,:,:) = prctile(s.arrIRFdist(end,:,:,:),s.estimator.pct, 3);
s.vVariables(:,end+1) = "tradebalance";


end