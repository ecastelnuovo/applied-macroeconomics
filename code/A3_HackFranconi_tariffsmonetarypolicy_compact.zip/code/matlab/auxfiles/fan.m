function count = fan(y,xHi,xLo,faceColor,linestyle,faceAlpha,edgeThick,count) 
if edgeThick > 0
    faceColorLight = (1-faceAlpha)*faceColor + faceAlpha*[1 1 1];
    linestyle = '-.';
    if count > 0; linestyle = ':';    end
    plot(y,xHi,linestyle,'Color',faceColor,'Linewidth',edgeThick,'HandleVisibility','off') 
    plot(y,xLo,linestyle,'Color',faceColor,'Linewidth',edgeThick,'HandleVisibility','off') 
    count = count + 1;
else
    fill([y fliplr(y)],[xHi' fliplr(xLo')],'b',...
    'FaceColor',faceColor,'FaceAlpha',faceAlpha,'EdgeColor','none','HandleVisibility','off')
    count = 0;
end

end