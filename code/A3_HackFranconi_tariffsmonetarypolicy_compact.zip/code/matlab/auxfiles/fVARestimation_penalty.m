function s = fVARestimation_penalty(s, tData)
% Takes VAR structure and data table as input, loads the data, and estimates
% the specified VAR model. Estimation results are appended to the input structure.

%%% -------------------------
%%% Data preparation
%%% -------------------------

% Time index
idstart = find(tData.(s.datevar) == datetime(s.vSample(1)));
idend   = find(tData.(s.datevar) == datetime(s.vSample(2)));

% Data to matrix and set missings to zero if specified
mData = tData{idstart:idend, s.vVariables};
if isfield(s, 'missingzero') && s.missingzero
    mData(isnan(mData)) = 0;
end

% Load structure variable to workspace as desired
lags            = s.lags;
boDeterministic = isfield(s, 'detpolynorder') && s.detpolynorder >= 0;
if boDeterministic
    nex = s.detpolynorder + 1; % number of deterministic variables
else
    nex = 0;
end

% Prepare data matrices
[nobs, nvar] = size(mData);
Y = mData(lags+1:end, :);
X = nan(nobs-lags, nvar*lags + boDeterministic*nex);

% Add lags
for i = 1:lags
    X(:, (i-1)*nvar+1 : i*nvar) = mData(lags-i+1:end-i, :);
end

% Add deterministic variables (centered and scaled time polynomial)
if boDeterministic
    t = (1:(nobs-lags))';                          % raw time index
    z = (t - mean(t)) / std(t);                    % centered & scaled
    for i = 0:s.detpolynorder
        X(:,nvar*lags+i+1) = z.^i;                 % constant + poly(z)
    end
end

%%% -------------------------
%%% Estimation
%%% -------------------------

if ~strcmp(s.estimator.name, "bvar_inversewishart")
    error("estimator not implemented")
end

% Shorthands
T         = nobs - lags;
p         = lags;
n         = nvar;
nd        = s.estimator.nd;
bburn     = s.estimator.burn;
H         = s.estimator.H;

% Companion form scaffolding
J = [eye(n); repmat(zeros(n), p-1, 1)];
F = zeros(n*p, n*p);
for i = 1:p-1
    F(i*n+1:(i+1)*n, (i-1)*n+1:i*n) = eye(n);
end

% OLS estimates
B      = (X' * X) \ (X' * Y);
U      = Y - X * B;
Sigmau = U' * U / (T - p*n - 1);
F(1:n, 1:n*p) = B(1:n*p, :)';

% ---------- Penalty-function spec ----------
s.penalty.vars = string([s.vVariables(s.vShockPos)]);
vAll    = string(s.vVariables);       % ensure string
penVars = string(s.penalty.vars);     % ensure string (can be scalar or vector)
s.penalty.nshocks = numel(penVars);

RR = zeros(n);
RR(1,1) = 1; % sign restrictions (columns = shocks; rows = IRFs restricted): the shock variable is ordered first

% ---------- Prior objects for inverse-Wishart / Normal ----------
N0    = zeros(size(X',1), size(X,2));
nnu0  = 0;
nnuT  = T + nnu0;
NT    = N0 + X' * X;
Bbar0 = B;
S0    = Sigmau;
ST    = (nnu0/nnuT) * S0 + (T/nnuT) * Sigmau ...
      + (1/nnuT) * ((B - Bbar0)') * N0 * (NT \ eye(n*p + boDeterministic*nex)) * (X' * X) * (B - Bbar0);
STinv = ST \ eye(n);

% ---------- Parallel setup ----------
if isempty(gcp('nocreate')), parpool('local', 4); end
sc = parallel.pool.Constant(RandStream('Threefry'));

% ---------- Posterior sampling with per-draw identification: redrawn until nd draws satisfy the restrictions ----------
Ltilde      = NaN(nd, H+1, n, s.penalty.nshocks);  % IRFs: draws × horizon × vars × shocks
epsHistilde = NaN(nd, T,   s.penalty.nshocks);     % structural shocks (identified columns)
nfound = 0; offset = 0; rate = 1;                  % valid draws are taken in substream order, so the result does not depend on the batch size
while nfound < nd
    nb = min(nd, ceil((nd - nfound) / rate) + 100);
    Lb = NaN(nb, H+1, n, s.penalty.nshocks); Eb = NaN(nb, T, s.penalty.nshocks); ok = false(nb, 1);
    parfor ib = 1:nb
        iter = offset + ib;
        stream = sc.Value; stream.Substream = iter; RandStream.setGlobalStream(stream);

        % 1) Draw Sigma_u from IW
        R         = mvnrnd(zeros(n,1), STinv/nnuT, nnuT)';   % n×nnuT
        Sigmadraw = (R * R') \ eye(n);

        % 2) Draw B | Sigma_u
        bbeta  = B(:);
        SigmaB = kron(Sigmadraw, NT \ eye(n*p + boDeterministic*nex));
        SigmaB = (SigmaB + SigmaB) / 2;
        Bdraw  = mvnrnd(bbeta, SigmaB);
        Bdraw  = reshape(Bdraw, n*p + boDeterministic*nex, n);

        % 3) Companion for this draw
        F_temp = F;
        F_temp(1:n, 1:n*p) = Bdraw(1:n*p, :)';

        % 4) Identification by penalty function for this draw
        LCdraw = chol(Sigmadraw, 'lower');
        sd     = sqrt(diag(Sigmadraw));
        [mufactor, fflag] = uhligpenalty(LCdraw, F_temp, sd, RR, s.penalty.nper, s.penalty.nshocks);
        if fflag == 0 || any(~isfinite(mufactor(:)))
            continue
        end

        % 5) IRFs using identified impact matrix
        IRF_T = vm_irf(F_temp, J, mufactor, H+1, n, [mufactor; zeros((p-1)*n, size(mufactor,2))]);
        L_local = NaN(1, H+1, n, s.penalty.nshocks);
        nshocks_here = min(size(IRF_T,3), s.penalty.nshocks);
        for ss = 1:nshocks_here
            L_local(1,:,:,ss) = IRF_T(:,:,ss);
        end

        % 6) Structural shocks for the identified columns (T × nshocks)
        Utildedraw = Y - X * Bdraw;                                           % T × n
        E          = (mufactor(1:n,1:s.penalty.nshocks) \ Utildedraw')';       % T × nshocks
        eps_local  = NaN(1, T, s.penalty.nshocks); eps_local(1,:,:) = E;

        Lb(ib,:,:,:) = L_local;
        Eb(ib,:,:)   = eps_local;
        ok(ib)       = true;
    end
    idx  = find(ok); take = idx(1:min(numel(idx), nd - nfound));
    Ltilde(nfound+1:nfound+numel(take),:,:,:) = Lb(take,:,:,:);
    epsHistilde(nfound+1:nfound+numel(take),:,:) = Eb(take,:,:);
    nfound = nfound + numel(take); offset = offset + nb; rate = max(nfound / offset, 0.05);
end

% ---------- Burn-in ----------
if bburn > 0
    Ltilde      = Ltilde(bburn+1:end, :, :, :);
    epsHistilde = epsHistilde(bburn+1:end, :, :);
end

% ---------- Scaling ----------
if isnumeric(s.scalingfactor) && ~isempty(s.scalingfactor)
    % Normalization by impact and scale
    Ltilde       = Ltilde ./ Ltilde(:,1,s.vShockPos,:) * s.scalingfactor;

elseif ischar(s.scalingfactor) && strcmp(s.scalingfactor, "unit")
    % First: drop draws where the driver impact is ~0
    tol = 1e-4;
    driverIdx = zeros(1, s.penalty.nshocks);
    for k = 1:s.penalty.nshocks
        driverIdx(k) = find(strcmp(vAll, s.penalty.vars{k}), 1);
    end

    keep = true(size(Ltilde,1),1);
    for k = 1:s.penalty.nshocks
        impact = Ltilde(:,1,driverIdx(k),k);
        keep   = keep & abs(impact) > tol;
    end

    Ltilde      = Ltilde(keep,:,:,:);
    epsHistilde = epsHistilde(keep,:,:);

    % Now normalize each identified shock by its driver variable's impact
    for k = 1:s.penalty.nshocks
        denom = Ltilde(:,1,driverIdx(k),k);
        Ltilde(:,:,:,k) = Ltilde(:,:,:,k) ./ denom;
    end
end

% ---------- Percentiles & packaging ----------
Ltilde_ptile   = prctile(Ltilde, s.estimator.pct);       % pct × H+1 × n × nshocks

% Apply scaling factor 
    if isnumeric(s.scalingfactor)
        Ltilde = Ltilde * s.scalingfactor;
    elseif strcmp(s.scalingfactor,"unit")
        % Apply unit scaling for each shock
        for i = 1:size(Ltilde,4)
            Ltilde(:,:,:,i) = Ltilde(:,:,:,i) ./ Ltilde(:,1,s.vShockPos(i),i) * 10;
            Ltilde_ptile(:,:,:,i) = Ltilde_ptile(:,:,:,i) ./ Ltilde_ptile(:,1,s.vShockPos(i),i) * 10;
        end
    end


s.arrIRF       = permute(Ltilde_ptile, [3 2 1 4]);       % n × (H+1) × pct × nshocks
s.arrIRFdist   = permute(Ltilde, [3 2 1 4]);             % n × (H+1) × draws × nshocks
s.VARshocks    = squeeze(prctile(epsHistilde, 50, 1));   % T × nshocks (median)

%%% -------------------------
%%% Console summary
%%% -------------------------
fprintf("----------------------------------------------------------------------\n")
fprintf("Estimation completed successfully\n\n")
fprintf("Model: %s\n", s.name)
fprintf("Variables: %s\n", strjoin(cellstr(s.vVariables), ", "))
fprintf("Sample: %s - %s\n", datestr(tData{idstart, s.datevar}), datestr(tData{idend, s.datevar}))
fprintf("Lags: %d\n", s.lags)
fprintf("Identified shocks (order): %s\n", strjoin(s.penalty.vars, ", "))
fprintf("Estimator: %s\n", s.estimator.name)
fprintf("----------------------------------------------------------------------\n")
end