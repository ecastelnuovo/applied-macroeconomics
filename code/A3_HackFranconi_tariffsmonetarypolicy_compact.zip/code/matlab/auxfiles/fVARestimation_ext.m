function s = fVARestimation_ext(s, tData)
% Takes VAR structure and data table as input, loads the data, and estimates
% the specified VAR model. Estimation results are appended to the input structure

%%% -------------------------
%%% Data preparation
%%% -------------------------

% Time index
idstart = find(tData.(s.datevar) == datetime(s.vSample(1)));
idend   = find(tData.(s.datevar) == datetime(s.vSample(2)));

% Data to matrix and set missings to zero if specified
mData   = tData{idstart:idend,s.vVariables};
if isfield(s, 'missingzero') && s.missingzero
    mData(isnan(mData)) = zeros(size(mData(isnan(mData))));
end

% Flags
lags            = s.lags;
boDeterministic = isfield(s,'detpolynorder') && s.detpolynorder >= 0;

% Exogenous flag (VARX)
if isfield(s, 'Exovar')
    boExovar = sum(~(s.Exovar == ""));
else
    boExovar = 0;
end

% Number of deterministic columns to add to X (constant + poly trend + exo)
if boDeterministic
    nex = s.detpolynorder + boExovar + 1;
else
    nex = 0;
end

% Prepare data matrices
[nobs, nvar] = size(mData);
Y = mData(lags+1:end,:);
X = nan(nobs-lags, nvar*lags + boDeterministic*nex);

% Add lags
for i = 1:lags
    X(:,(i-1)*nvar+1:i*nvar) = mData(lags-i+1:end-i,:);
end

% Add deterministic variables (centered/scaled time polynomial)
if boDeterministic
    t = (1:(nobs-lags))';
    z = (t - mean(t)) / std(t);
    for i = 0:s.detpolynorder
        X(:,nvar*lags+i+1) = z.^i;   % constant + poly(z)
    end
end

% Add exogenous variable(s) (e.g., narrative shock) at the END of X
if boExovar >= 1
    ExoData = tData{idstart:idend, s.Exovar};
    X(:, (end-boExovar+1):end) = ExoData(lags+1:end, :);
end

%%% -------------------------
%%% Estimation
%%% -------------------------

if strcmp(s.estimator.name, "bvar_inversewishart")
    % Shorthands
    T           = nobs-lags;
    p           = lags;
    n           = nvar;
    nd          = s.estimator.nd;
    bburn       = s.estimator.burn;
    H           = s.estimator.H;
    vShockPos   = s.vShockPos;  % used only for orth IRFs

    % Companion-form scaffolding
    J = [eye(n); repmat(zeros(n),p-1,1)];
    F = zeros(n*p,n*p);
    I = eye(n);
    for i=1:p-1
        F(i*n+1:(i+1)*n,(i-1)*n+1:i*n) = I;
    end

    % OLS / posterior baseline
    B      = (X'*X) \ (X'*Y);
    U      = Y - X * B;
    Sigmau = U'*U / (T - p*n - 1);
    LC     = chol(Sigmau)';   % for orth IRFs
    Omega1 = [LC; zeros((p-1)*n, size(LC,2))];
    A0     = (LC') \ eye(size(LC,1));
    F(1:n,1:n*p) = B(1:n*p,:)';

    nKeep   = nd - bburn;
    nShocks = length(s.vShockPos);

    % Storage
    Ltilde          = zeros(nKeep, H+1, n, max(nShocks,1)); % works for both modes

    % Prior/posterior ingredients (as in fVARestimation.m)
    N0   = zeros(size(X',1), size(X,2));
    nnu0 = 0;
    nnuT = T + nnu0;
    NT   = N0 + X'*X;
    Bbar0 = B;
    S0    = Sigmau;
    ST    = (nnu0/nnuT)*S0 + (T/nnuT)*Sigmau ...
          + (1/nnuT) * ((B - Bbar0)') * N0 * (NT \ eye(n*p+nex)) * (X'*X) * (B - Bbar0);
    STinv = ST \ eye(n);

    % Parallel posterior draws
    if isempty(gcp('nocreate')); parpool('local',4); end
    sc = parallel.pool.Constant(RandStream('Threefry'));

parfor iter = 1:nd
    stream = sc.Value; stream.Substream = iter; RandStream.setGlobalStream(stream);

    % Draw Sigma and B | Sigma
    R         = mvnrnd(zeros(n,1), STinv/nnuT, nnuT)';
    Sigmadraw = (R * R') \ eye(n);

    bbeta   = B(:);
    SigmaB  = kron(Sigmadraw, NT \ eye(n*p+nex));
    SigmaB  = (SigmaB + SigmaB') / 2;
    Bdraw   = mvnrnd(bbeta, SigmaB);
    Bdraw   = reshape(Bdraw, n*p+nex, n);

    % Create a local temporary storage for this iteration
    Ltilde_iter = zeros(H+1, n, max(nShocks,1));

    % Update companion F with AR part only
    F_temp = F;
    F_temp(1:n,1:n*p) = Bdraw(1:n*p,:)';

    %%% ----------------------------------------------------------
    %%% IRFs: ORTH vs EXO
    %%% ----------------------------------------------------------
    if ~isfield(s,'shocktype') || strcmpi(s.shocktype,'orth')
        LCdraw  = chol(Sigmadraw, 'lower');
        IRF_T   = vm_irf(F_temp, J, LCdraw, H+1, n, Omega1);
        for ss = 1:nShocks
            shock_idx = vShockPos(ss);
            Ltilde_iter(:,:,ss) = IRF_T(:,:,shock_idx);
        end

    elseif strcmpi(s.shocktype,'exo')
        if boExovar < 1
            error("shocktype='exo' but no Exovar provided.");
        end

        % Lag matrices Phi and the loading D of the exogenous variable
        Phi = cell(p,1);
        for ii=1:p
            Phi{ii} = (Bdraw((ii-1)*n+1:ii*n,:))';
        end

        Dblock = Bdraw(n*p + (nex - boExovar + 1): n*p + nex, :);
        D      = Dblock';

        e_exo = zeros(boExovar,1); e_exo(1) = 1;

        Yirf  = zeros(H+1, n);
        Ylags = zeros(n, p);

        Yirf(1,:) = (D * e_exo)';
        Ylags = [Yirf(1,:)', Ylags(:,1:p-1)];

        for h = 2:(H+1)
            yh = zeros(n,1);
            for ii=1:p
                yh = yh + Phi{ii} * Ylags(:,ii);
            end
            Yirf(h,:) = yh';
            Ylags = [yh, Ylags(:,1:p-1)];
        end

        Ltilde_iter(:,:,1) = Yirf;

    else
        error("Unknown s.shocktype: use 'orth' or 'exo'.");
    end
    %%% ----------------------------------------------------------

    % Save this iteration's IRF block
    Ltilde(iter,:,:,:) = Ltilde_iter;
end

    % Drop burn-in
    Ltilde = Ltilde(bburn+1:end,:,:,:);

    % Percentiles
    Ltilde_ptile = prctile(Ltilde, s.estimator.pct);

    % Scaling (applies to either mode). For exo, this scales the one-unit shock.

if isnumeric(s.scalingfactor)

    if (~isfield(s,'shocktype')) || strcmpi(s.shocktype,'orth')
        % Orthogonal shocks: normalize by impact and scale
        Ltilde       = Ltilde ./ Ltilde(:,1,s.vShockPos,:) * s.scalingfactor;
        Ltilde_ptile = prctile(Ltilde, s.estimator.pct);   % percentiles of the normalised draws

    elseif strcmpi(s.shocktype,'exo')
    % Exogenous shock: each draw normalised by its impact on the tariff rate
    shockvar_idx = s.vShockPos;  % index of ln_tariffrate in Y
    impact_draws = squeeze(Ltilde(:,1,shockvar_idx,1));  % [ndraw × 1]
    
    % Avoid divide-by-zero
    impact_draws(impact_draws == 0) = NaN;

    % Rescale each draw’s full IRF by its own impact
    for d = 1:size(Ltilde,1)
        Ltilde(d,:,:,1) = Ltilde(d,:,:,1) ./ impact_draws(d) * s.scalingfactor;
    end

    % Recompute percentiles after rescaling
    Ltilde_ptile = prctile(Ltilde, s.estimator.pct);

    end

elseif ischar(s.scalingfactor) && strcmpi(s.scalingfactor,"unit")

    if (~isfield(s,'shocktype')) || strcmpi(s.shocktype,'orth')
        % Unit normalization by impact for orthogonal shocks
        for iShock = 1:size(Ltilde,4)
            Ltilde(:,:,:,iShock)       = Ltilde(:,:,:,iShock) ./ Ltilde(:,1,s.vShockPos(iShock),iShock);
            Ltilde_ptile(:,:,:,iShock) = Ltilde_ptile(:,:,:,iShock) ./ Ltilde_ptile(:,1,s.vShockPos(iShock),iShock);
        end
    elseif strcmpi(s.shocktype,'exo')
        % Exogenous shocks already represent a one-unit change
        % → leave IRFs unchanged
    end

end
% ===============================================================

    % Save results back into s
    s.arrIRF        = permute(Ltilde_ptile, [flip(1:3) 4]);  % n × (H+1) × pct × shocks
    s.arrIRFdist    = permute(Ltilde, [3 2 1 4]);            % n × (H+1) × draws × shocks

    %%% Summary printout
    fprintf("----------------------------------------------------------------------\n")
    fprintf("Estimation completed successfully\n\n")
    fprintf("Model: " + s.name + "\n")
    fprintf("Variables: " + strjoin(s.vVariables, ", ") + "\n")
    fprintf("Sample: " + datestr(tData{idstart,s.datevar}) + " - " + datestr(tData{idend,s.datevar}) + "\n")
    fprintf("Lags: " + s.lags + "\n")
    if (~isfield(s,'shocktype')) || strcmpi(s.shocktype,'orth')
        fprintf("IRF mode: ORTH (Cholesky)\n")
        fprintf("Shocks: " + strjoin(s.vVariables(s.vShockPos), ", ") + "\n")
    else
        fprintf("IRF mode: EXO (VARX to %s)\n", string(s.Exovar));
    end
    fprintf("Estimator: " + s.estimator.name + "\n")
    fprintf("----------------------------------------------------------------------\n")
else
    error("estimator not implemented")
end
end