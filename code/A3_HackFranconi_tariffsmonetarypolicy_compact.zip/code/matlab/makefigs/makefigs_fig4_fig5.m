% makefigs_fig4_fig5.m - Figures 3 and 4 (baseline counterfactuals). Expects
% sTariff, sFFRcf, sINFcf, sGDPcf loaded by stage02_figures_maintext.m.

setupfigs;

s1  = sTariff;

col = col_red;
col1 = col_dgray;

facealpha = 0.2;


% Font and line-width scaling, set per panel below (Figure 3 panels at .4\textwidth, Figure 4 panels at .3\textwidth)
fs = 1.2;
lw = 1.2;


mYlim = [-4 , 6.5; -2, 4; -1, 3; -8, 4; -8, 2; -8 6; -3, 1.5; -1.5, 2; -4, 2.4; -0.6, 0.9];   % y-limits, one row per variable of s0.vVariables

for s0 = [sFFRcf sINFcf sGDPcf]

row = find(s0.name == ["stabffr_base" "stabinf_base" "stabgdp_base"]);   % counterfactual 1, 2, 3

for v = s0.vVariables
    
    clear pl;
    fn = exhibit_path("fig3", v, row);
    if fn == ""; fn = exhibit_path("fig4", v, row); end
    if fn == ""; continue; end
    if contains(fn, "figure_3"); fs = 1.2; lw = 1.2; else; fs = 1.6; lw = 1.6; end

    ind         = find(s0.vVariables == v);
    medianpos   = ceil(size(s0.arrIRF,3)/2);
    horax       = 0:s0.H-1;
    H           = s0.H;

    % Initialize figure with bands
    fig = figure('DefaultAxesFontSize',15*fs, 'Units','points','Position',[100 100 420 315]);
    hold on;
    count = fan(horax, s0.arrIRF(ind,1:H,medianpos+2)',s0.arrIRF(ind,1:H,medianpos-2)',col,'-',facealpha*0.75*lw,0,0);
    count = fan(horax, s0.arrIRF(ind,1:H,medianpos+1)',s0.arrIRF(ind,1:H,medianpos-1)',col,'-',facealpha*1.25*lw,0,count);
    
    % Add point estimates from s1
    ind1 = find(s1.vVariables == v);
    pl(2)= plot(horax, s1.arrIRF(ind1,1:H,medianpos), '-.','Color',col1,'Linewidth',3*lw,'MarkerSize',8);

    % Main estimate
    pl(1) = plot(horax, s0.arrIRF(ind,1:H,medianpos), '-','Color',col,'Linewidth',3*lw);

    box("on");
    set(gcf, 'unit', 'inches');
    yline(0,'k-','HandleVisibility','off');
    xlabel(xname)
    ylim(mYlim(ind,:))
    if (v == "ffr" || v == "tradebalance") && s0.name == "stabffr_base"
        ncol = 2; if v == "tradebalance"; ncol = 1; end   % Figure 4: single column, the panel is narrower
        legend(pl, "Counterfactual", "Baseline", 'Box', 'off', 'NumColumns', ncol, 'Location', 'North', 'FontSize', 15*fs)
    end
    hold off;

    ylabel(getvar(v))
    if ~contains(fn, "figure_3"); ax = gca; ax.Position(3) = ax.Position(3) - 0.02; end   % narrower plot box: the panels overlap in the draft's 4-column rows
    fn_print(fig, ['''' char(fn) ''''])
    close(fig)
end

end
