% makefigs_fig3.m - Figure C.1. Panel (g) shows the trade balance implied by the
% baseline VAR (footnote 23). Expects sTariff and the augmented structures
% sTariff<type><variable> loaded by stage04_figures_appendix.m.

setupfigs;


col = col_blue;
col1 = col_dgray;

facealpha = 0.2;


% Font and line-width scaling (panel included at .3\textwidth in the draft)
fs = 1.6;
lw = 1.6;

for type = ["fiscal_" "infrate_" "policyrate_" "realactivity_"  "add_" ""]

for v = ["ln_rreceipttotal_nd" "ln_rgov" "ln_rfdebt_sa" "ln_rduties" "gr_ppi_nsa" "gr_cpic" "infexp_mich1y" "ffr_shadow" "gs1" "outputgap" "uer" "ln_indpro" "ln_rpce" "ln_rimp_cons" "tradebalgdp" "tradebalance"]

    if exhibit_path("figc1", v) == ""; continue; end

    % Check whether object exists
    if v == "tradebalance" && type == ""
        s0 = sTariff;        % baseline VAR, trade balance from sample means (footnote 23)
    else
        try 
            eval(strcat("s0 = sTariff", type, v,";"));
        catch
            continue;
        end
    end

    clear pl;

    ind         = find(s0.vVariables == v);
    medianpos   = ceil(size(s0.arrIRF,3)/2);
    horax       = 0:s0.H-1;
    H           = s0.H;

    % Initialize figure with bands
    fig = figure('DefaultAxesFontSize',15*fs, 'Units','points','Position',[100 100 420 315]);
    hold on;
    pl(1) = plot(horax, s0.arrIRF(ind,1:H,medianpos), '-','Color',col,'Linewidth',3*lw);
    count = fan(horax, s0.arrIRF(ind,1:H,medianpos+2)',s0.arrIRF(ind,1:H,medianpos-2)',col,'-',facealpha*0.75*lw,0,0);
    count = fan(horax, s0.arrIRF(ind,1:H,medianpos+1)',s0.arrIRF(ind,1:H,medianpos-1)',col,'-',facealpha*1.25*lw,0,count);
    
    box("on");
    set(gcf, 'unit', 'inches');
    yline(0,'k-','HandleVisibility','off');
    xlabel(xname)
    hold off;

    ylabel(getvar(v))
    ax = gca; ax.Position(3) = ax.Position(3) - 0.02;    % narrower plot box: the panels overlap in the draft's 4-column rows
    fn_print(fig, ['''' char(exhibit_path("figc1", v)) ''''])
    close(fig)
end
end
