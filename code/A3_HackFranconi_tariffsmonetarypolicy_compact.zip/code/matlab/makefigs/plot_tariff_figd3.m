% plot_tariff_figd3.m - Figure D.3: the three tariff rate series.
% Expects tData, sTariff and the colours of setupfigs.m.

s = sTariff;

idstart = find(tData.(s.datevar) == datetime(s.vSample(1)));
idend   = find(tData.(s.datevar) == datetime(s.vSample(2)));

dates_all  = tData{idstart:idend, s.datevar};
tariffrate = tData{idstart:idend, s.shockname};

tariff_nw = tData.tariffrate_nw(idstart:idend);

tariff_nw_rescaled = ...
    (tariff_nw - mean(tariff_nw, 'omitnan')) ./ std(tariff_nw, 'omitnan') ...
    .* std(tariffrate, 'omitnan') ...
    + mean(tariffrate, 'omitnan');

sgu_index = tData.sgu25_traderestrict(idstart:idend);
sgu_index_rescaled = ...
    (sgu_index - mean(sgu_index, 'omitnan')) ./ std(sgu_index, 'omitnan') ...
    .* std(tariffrate, 'omitnan') ...
    + mean(tariffrate, 'omitnan');

figure('Units','centimeters','Position',[2 2 30 15]);

h1 = plot(dates_all, tariffrate, 'LineWidth', 2, 'Color', col_blue, 'LineStyle',"-"); hold on;
h2 = plot(dates_all, tariff_nw_rescaled, 'LineWidth', 2,'Color', col_dgray, 'LineStyle',":");
h3 = plot(dates_all, sgu_index_rescaled, 'LineWidth', 2, 'Color', col_red, 'LineStyle',"--");
ylabel('Percent','Interpreter','latex','FontSize',12.5);   % 12.5 pt prints at 8 pt at full text width
set(gca,'FontSize',12.5);

grid on;
box on;
xlim([datetime(1990,1,1) datetime(2025,1,1)]);

legend([h1 h2 h3], ...
    {'Trade-weighted average tariff rate', 'Unweighted average tariff rate' , 'Trade restrictiveness index'}, ...
    'Interpreter','latex', 'FontSize',12.5, ...
    'Location','north');

exportgraphics(gcf, char(exhibit_path("figd3", "")));
close(gcf)
