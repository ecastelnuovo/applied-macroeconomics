% plot_tariff_fig1.m - Figure 1: tariff rate and structural tariff shock.
% Expects tData, sTariff and the colours of setupfigs.m.

s = sTariff;

% Time index for the estimation sample
idstart = find(tData.(s.datevar) == datetime(s.vSample(1)));
idend   = find(tData.(s.datevar) == datetime(s.vSample(2)));

dates_all  = tData{idstart:idend, s.datevar};      % full-sample dates
tariffrate = tData{idstart:idend, s.shockname};    % tariff rate (level)
dates_shk  = dates_all(s.lags+1:end);              % shocks start after the lags
shock      = zscore(s.VARshocks);                  % structural tariff shock (s.d. units)

figure('Units','centimeters','Position',[2 2 35 18]);
tiledlayout(2,1,'TileSpacing','compact','Padding','compact');

% Panel 1: tariff rate (level)
g1=plot(dates_all, tariffrate, 'LineWidth', 2, 'Color', col_blue);
ylabel('Percent', 'Interpreter','latex', 'FontSize',15);   % 15 pt prints at 8 pt at full text width
set(gca,'FontSize',15);
grid on; box off; xlim([dates_all(1) dates_all(end)]); hold on;
xlim([datetime(1990,1,1) datetime(2025,1,1)]);

% Right axis
yyaxis right

g2=bar(dates_shk, shock, ...
    'FaceColor', col_red, ...
    'FaceAlpha', 0.5, ...
    'EdgeColor', 'none');

yline(0, 'k-');
ylim([-4 6]);
ylabel('Standard deviations', 'Interpreter','latex', 'FontSize',15);

ax = gca;
ax.YAxis(2).Color = col_red;

legend([g1 g2], ...
    {'Average tariff rate (left axis)', 'Standardized tariff shock (right axis)'}, ...
    'Interpreter','latex', 'FontSize',15, ...
    'Location','north');

exportgraphics(gcf, char(exhibit_path("fig1", "")));
close(gcf)
