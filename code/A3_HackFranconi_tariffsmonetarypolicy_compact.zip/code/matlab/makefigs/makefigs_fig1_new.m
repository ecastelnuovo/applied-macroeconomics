% makefigs_fig1_new.m - Figure 2.
% Expects the structures loaded by stage02_figures_maintext.m.

setupfigs;


s0 = sTariff;

col = col_blue;
col1 = col_dgray;

facealpha = 0.2;


% Font and line-width scaling (panel included at .4\textwidth in the draft)
fs = 1.2;
lw = 1.2;


for v = s0.vVariables
    
    clear pl;
    if exhibit_path("fig2", v) == ""; continue; end

    ind         = find(s0.vVariables == v);
    medianpos   = ceil(size(s0.arrIRF,3)/2);
    horax       = 0:s0.H-1;
    H           = s0.H;

    % Initialize figure with bands
    fig = figure('DefaultAxesFontSize',15*fs, 'Units','points','Position',[100 100 420 315]);
    hold on;
    count = fan(horax, s0.arrIRF(ind,1:H,medianpos+2)',s0.arrIRF(ind,1:H,medianpos-2)',col,'-',facealpha*0.75*lw,0,0);
    count = fan(horax, s0.arrIRF(ind,1:H,medianpos+1)',s0.arrIRF(ind,1:H,medianpos-1)',col,'-',facealpha*1.25*lw,0,count);

    % Main estimate
    pl(1) = plot(horax, s0.arrIRF(ind,1:H,medianpos), '-','Color',col,'Linewidth',3*lw);

    box("on");
    set(gcf, 'unit', 'inches');
    yline(0,'k-','HandleVisibility','off');
    xlabel(xname)
    if v == "ln_rinv"; ylim([-7 10]); end   % margin below the 90 % band
    hold off;

    ylabel(getvar(v))
    fn_print(fig, ['''' char(exhibit_path("fig2", v)) ''''])
    close(fig)
end