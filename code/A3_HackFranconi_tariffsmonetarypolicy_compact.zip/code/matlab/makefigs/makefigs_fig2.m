% makefigs_fig2.m - Figure D.4.
% Expects the structures loaded by stage04_figures_appendix.m.

setupfigs;

s0 = sTariffSGUindex;
s1 = sTariffUnweighted;

col = col_blue;
col1 = col_dgray;

facealpha = 0.2;


% Font and line-width scaling (panel included at .25\textwidth in the draft)
fs = 1.92;
lw = 1.92;

for v = s0.vVariables
    
    clear pl;
    if exhibit_path("figd4", v) == ""; continue; end

    ind         = find(s0.vVariables == v);
    medianpos   = ceil(size(s0.arrIRF,3)/2);
    horax       = 0:s0.H-1;
    H           = s0.H;

    % Initialize figure with bands
    fig = figure('DefaultAxesFontSize',15*fs, 'Units','points','Position',[100 100 420 315]);
    hold on;
    pl(1) = plot(horax, s0.arrIRF(ind,1:H,medianpos), '-','Color',col,'Linewidth',3*lw);
    count = fan(horax, s0.arrIRF(ind,1:H,medianpos+2)',s0.arrIRF(ind,1:H,medianpos-2)',col,'-',facealpha*0.75*lw,0,0);
    count = fan(horax, s0.arrIRF(ind,1:H,medianpos+1)',s0.arrIRF(ind,1:H,medianpos-1)',col,'-',facealpha*1.25*lw,0,count);
    
    % Add point estimates from s1
    ind1 = find(s1.vVariables == v);
    if v == "sgu25_traderestrict"; ind1 = find(s1.vVariables == "tariffrate_nw"); end
    pl(2)= plot(horax, s1.arrIRF(ind1,1:H,medianpos), '-.','Color',col1,'Linewidth',3*lw,'MarkerSize',8);
    count = fan(horax, s1.arrIRF(ind1,1:H,medianpos+2)',s1.arrIRF(ind1,1:H,medianpos-2)',col1,'-.',facealpha*0.75*lw,1,1);
    count = fan(horax, s1.arrIRF(ind1,1:H,medianpos+2)',s1.arrIRF(ind1,1:H,medianpos-2)',col1,'--',facealpha*0.25*lw,0,count);
    
    
    box("on");
    set(gcf, 'unit', 'inches');
    yline(0,'k-','HandleVisibility','off');
    xlabel(xname)
    if v == "ln_rgdp"
        legend(pl, "Trade restrictiveness index", "Unweighted average tariff rate", 'Box', 'off', 'NumColumns', 1, 'Location', 'North', 'FontSize', 18)   % legend font 18 pt (prints at 5 pt)
        % raise the upper y-limit so that the legend (22 % of the plot box) clears the highest plotted band
        yl = ylim; yd = get(findall(gca, '-property', 'YData'), 'YData');   % findall: the band fills have hidden handles
        if ~iscell(yd); yd = {yd}; end
        ymax = max(cellfun(@(y) max(y(:), [], 'omitnan'), yd));
        ylim([yl(1), yl(1) + (ymax - yl(1)) / 0.75]);
    end
    hold off;

    ylabel(getvar(v))
    ax = gca; ax.Position(3) = ax.Position(3) - 0.035;   % narrower plot box: the panels overlap in the draft's 5-column rows
    fn_print(fig, ['''' char(exhibit_path("figd4", v)) ''''])
    close(fig)
end