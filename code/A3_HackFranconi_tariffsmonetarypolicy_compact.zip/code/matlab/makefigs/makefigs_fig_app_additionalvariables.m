% makefigs_fig_app_additionalvariables.m - Figure D.8. The gray lines are the 15 augmented VARs of Figure C.1.
% Expects the structures loaded by stage04_figures_appendix.m.

setupfigs;

s0 = sTariff;

col1 = col_blue;
col = col_dgray;

facealpha = 0.2;


% Font and line-width scaling (panel included at .25\textwidth in the draft)
fs = 1.92;
lw = 1.92;


for vv = s0.vVariables
    clear pl;
    if exhibit_path("figd8", vv) == ""; continue; end

    % Initialize figure with bands
    fig = figure('DefaultAxesFontSize',15*fs, 'Units','points','Position',[100 100 420 315]);
    hold on;

    ind0 = find(s0.vVariables == vv);
    medianpos   = ceil(size(s0.arrIRF,3)/2);
    horax       = 0:s0.H-1;
    H           = s0.H;


    plot(horax, s0.arrIRF(ind0,1:H,medianpos), '-','Color',col1,'Linewidth',3*lw);
    count = fan(horax, s0.arrIRF(ind0,1:H,medianpos+2)',s0.arrIRF(ind0,1:H,medianpos-2)',col1,'-',facealpha*0.75*lw,0,0);
    count = fan(horax, s0.arrIRF(ind0,1:H,medianpos+1)',s0.arrIRF(ind0,1:H,medianpos-1)',col1,'-',facealpha*1.25*lw,0,count);


for type = ["fiscal_" "infrate_" "policyrate_" "realactivity_"  "add_"]

for v = ["ln_rreceipttotal_nd" "ln_rgov" "ln_rfdebt_sa" "ln_rduties" "gr_ppi_nsa" "gr_cpic" "infexp_mich1y" "ffr_shadow" "gs1" "outputgap" "uer" "ln_indpro" "ln_rpce" "ln_rimp_cons" "tradebalgdp"]

    % Check whether object exists
    try 
        eval(strcat("s1 = sTariff", type, v,";"));
    catch
        continue;
    end

    clear pl;
    

    ind         = find(s1.vVariables == vv);
    if vv == "tradebalance" && isempty(ind); ind = find(s1.vVariables == "tradebalgdp"); end   % VAR with the trade balance to GDP in place of exports and imports

    if ~isempty(ind)

    pl(2) = plot(horax, s1.arrIRF(ind,1:H,medianpos), '-','Color',col,'Linewidth',1*lw);
    end
    


end
end

    % reprint baseline PE
    pl(1) = plot(horax, s0.arrIRF(ind0,1:H,medianpos), '-','Color',col1,'Linewidth',3*lw);

    if strcmp(vv,"ln_rgdp")
        legend(pl, "Baseline", "Augmented VAR vectors", 'Box', 'off', 'NumColumns', 1, 'Location', 'Northwest', 'FontSize', 18)   % legend font 18 pt (prints at 5 pt)
        % raise the upper y-limit so that the legend (22 % of the plot box) clears the highest plotted band
        yl = ylim; yd = get(findall(gca, '-property', 'YData'), 'YData');   % findall: the band fills have hidden handles
        if ~iscell(yd); yd = {yd}; end
        ymax = max(cellfun(@(y) max(y(:), [], 'omitnan'), yd));
        ylim([yl(1), yl(1) + (ymax - yl(1)) / 0.75]);
    end

    box("on");
    set(gcf, 'unit', 'inches');
    yline(0,'k-','HandleVisibility','off');
    xlabel(xname)
    hold off;

    ylabel(getvar(vv))
    ax = gca; ax.Position(3) = ax.Position(3) - 0.035;   % narrower plot box: the panels overlap in the draft's 5-column rows
    fn_print(fig, ['''' char(exhibit_path("figd8", vv)) ''''])
    close(fig)
end