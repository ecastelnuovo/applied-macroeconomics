% spf_granger_table.m - Table D.2
% ------------------------------------------------------------------------------
% Expects tData, sTariff, pathRaw and pathTables in the workspace.
% Output: results_final/tables/table_d2.tex
% ------------------------------------------------------------------------------

%% 1. Identified shock with dates (same convention as plot_tariff_fig1.m)
if exist('sTariff','var'); s = sTariff; else; s = sDefault; end
assert(isfield(s,'VARshocks') && ~isempty(s.VARshocks), ...
    'spf_granger_table: no VARshocks in the model structure. Run fVARestimation first.');

idstart   = find(tData.(s.datevar) == datetime(s.vSample(1)));
idend     = find(tData.(s.datevar) == datetime(s.vSample(2)));
dates_all = tData{idstart:idend, s.datevar};
dates_shk = dates_all(s.lags+1:end);     % shocks start after the lags
shock     = s.VARshocks(:);              % structural tariff shock (s.d. units)

%% 2. Load SPF real net-export forecasts
pathSPF = pathRaw + "spf/spf_mean_rexport_level.xlsx";
tSPF    = readtable(pathSPF, 'VariableNamingRule', 'preserve');

YEAR = local_tonum(tSPF.YEAR);
QTR  = local_tonum(tSPF.QUARTER);
R2   = local_tonum(tSPF.REXPORT2);       % nowcast (t)
R3   = local_tonum(tSPF.REXPORT3);       % forecast t+1
R4   = local_tonum(tSPF.REXPORT4);       % forecast t+2
R5   = local_tonum(tSPF.REXPORT5);       % forecast t+3
R6   = local_tonum(tSPF.REXPORT6);       % forecast t+4

% Survey-quarter dates, first month of the quarter (matches tData DATE_Q)
ok   = ~isnan(YEAR) & ~isnan(QTR);
dSPF = datetime(YEAR(ok), 3*(QTR(ok)-1)+1, 1);
R2=R2(ok); R3=R3(ok); R4=R4(ok); R5=R5(ok); R6=R6(ok);
[dSPF, sidx] = sort(dSPF);
R2=R2(sidx); R3=R3(sidx); R4=R4(sidx); R5=R5(sidx); R6=R6(sidx);

%% 3. Expected change in net exports within each survey
exch1 = R3 - R2;       % E_t[ NX_{t+1} - NX_t ]   (1q ahead)
exch2 = R4 - R2;       % E_t[ NX_{t+2} - NX_t ]   (2q ahead)
exch3 = R5 - R2;       % E_t[ NX_{t+3} - NX_t ]   (3q ahead)
exch4 = R6 - R2;       % E_t[ NX_{t+4} - NX_t ]   (4q ahead)

%% 4. Regressors: the expected changes formed at the survey one quarter before the shock, matched by date
[tf, loc] = ismember(dates_shk - calquarters(1), dSPF);   % survey one quarter before each shock date
keep      = find(tf);
cdates    = dates_shk(keep);
yv        = shock(keep);
Xlag      = [exch1(loc(keep)), exch2(loc(keep)), exch3(loc(keep)), exch4(loc(keep))];
assert(~isempty(cdates), 'spf_granger_table: no overlapping dates between shock and SPF.');

predNames = [ "E_{t-1}[dNX] 1q"; "E_{t-1}[dNX] 2q"; ...
              "E_{t-1}[dNX] 3q"; "E_{t-1}[dNX] 4q" ];
nPred     = numel(predNames);

fprintf('\n==============================================================\n');
fprintf(' SPF net-export forecasts vs. identified tariff shock\n');
fprintf(' Model: %s | sample: %s to %s (%d quarters)\n', s.name, ...
    datestr(cdates(1)), datestr(cdates(end)), numel(cdates));
fprintf(' Test: shock_t = c + b_h * E_{t-1}[NX_{t-1+h}-NX_{t-1}] + e_t\n');
fprintf(' (no own lags of the shock; one horizon at a time, then jointly)\n');
fprintf('==============================================================\n');

%% 5. Five specifications: (1)-(4) one horizon at a time, (5) all jointly
% Rows = predictors, columns = regressions (classic regression-table layout)
specs = {1, 2, 3, 4, 1:4};
nSpec = numel(specs);
res   = cell(nSpec,1);
for j = 1:nSpec
    res{j} = predict_test(yv, Xlag(:,specs{j}));
end

% Per-coefficient p-value from the HAC t-ratio (identical to the 1-df Wald)
pcoef = @(o,pos) 2*(1 - normcdf(abs(o.b(pos)/o.se(pos))));

fprintf('%-18s%12s%12s%12s%12s%12s\n', 'predictor','(1)','(2)','(3)','(4)','(5)');
fprintf('%s\n', repmat('-',1,18+12*nSpec));
for k = 1:nPred
    fprintf('%-18s', char(predNames(k)));
    for j = 1:nSpec
        pos = find(specs{j} == k, 1);
        if isempty(pos), fprintf('%12s','');
        else, fprintf('%9.4f%-3s', res{j}.b(pos), pstar(pcoef(res{j},pos)));
        end
    end
    fprintf('\n%-18s','');
    for j = 1:nSpec
        pos = find(specs{j} == k, 1);
        if isempty(pos), fprintf('%12s','');
        else, fprintf('%12s', sprintf('(%.4f)', res{j}.se(pos)));
        end
    end
    fprintf('\n');
end
fprintf('%s\n', repmat('-',1,18+12*nSpec));
fprintf('%-18s', 'R2');
for j = 1:nSpec, fprintf('%12.3f', res{j}.R2); end
fprintf('\n%-18s', 'N');
for j = 1:nSpec, fprintf('%12d', res{j}.n); end
fprintf('\n Joint Wald, spec (5): chi2(%d) = %.2f, p = %.3f %s\n', ...
    res{nSpec}.q, res{nSpec}.Wald, res{nSpec}.pWald, pstar(res{nSpec}.pWald));
fprintf(' Newey-West HAC s.e.  * p<.10  ** p<.05  *** p<.01\n');

%% 6. Export LaTeX table (booktabs): rows = predictors, columns = specs (1)-(5)
rowlab = ["$E_{t-1}[NX_{t}-NX_{t-1}]$";   "$E_{t-1}[NX_{t+1}-NX_{t-1}]$"; ...
          "$E_{t-1}[NX_{t+2}-NX_{t-1}]$"; "$E_{t-1}[NX_{t+3}-NX_{t-1}]$"];

fid = fopen(char(pathTables + "table_d2.tex"), 'w');
fprintf(fid, '\\begin{tabular}{lccccc}\n\\toprule\n');
fprintf(fid, ' & (1) & (2) & (3) & (4) & (5)\\\\\n\\midrule\n');
for k = 1:nPred
    l1 = char(rowlab(k));  l2 = '';
    for j = 1:nSpec
        pos = find(specs{j} == k, 1);
        if isempty(pos)
            l1 = [l1 ' & '];  l2 = [l2 ' & ']; %#ok<AGROW>
        else
            st = pstar(pcoef(res{j},pos)); if ~isempty(st), st = ['$^{' st '}$']; end %#ok<AGROW>
            l1 = sprintf('%s & %.4f%s', l1, res{j}.b(pos), st);
            l2 = sprintf('%s & (%.4f)', l2, res{j}.se(pos));
        end
    end
    fprintf(fid, '%s\\\\\n', l1);
    fprintf(fid, '%s\\\\\n\\addlinespace\n', l2);
end
fprintf(fid, '\\midrule\n');
fprintf(fid, '$R^2$');
for j = 1:nSpec, fprintf(fid, ' & %.3f', res{j}.R2); end
fprintf(fid, '\\\\\nObservations');
for j = 1:nSpec, fprintf(fid, ' & %d', res{j}.n); end
fprintf(fid, '\\\\\n\\bottomrule\n\\end{tabular}\n');
fclose(fid);
fprintf(' Saved: results_final/tables/table_d2.tex\n\n');


%% ===================== local functions =====================
function s = pstar(p)
% Significance stars for a p-value.
if     p < 0.01, s = '***';
elseif p < 0.05, s = '**';
elseif p < 0.10, s = '*';
else,            s = '';
end
end

function y = local_tonum(x)
% Convert a column to double; text such as '#N/A' becomes NaN.
if isnumeric(x)
    y = x;
else
    y = str2double(string(x));
end
end

function out = predict_test(y, X)
% OLS of y on a constant and X; Newey-West HAC standard errors and Wald test of b = 0.
y = y(:);  q = size(X,2);

Z    = [ones(numel(y),1), X];
good = all(~isnan([y, Z]), 2);
yy   = y(good);  Z = Z(good,:);
n    = numel(yy);  k = size(Z,2);

b  = Z\yy;  u = yy - Z*b;

Lhac = floor(4*(n/100)^(2/9));
V    = local_nwcov(Z, u, Lhac);
idx  = 2:k;                     % positions of the X coefficients
R    = b(idx);
Wald = R' * (V(idx,idx) \ R);
pW   = 1 - chi2cdf(Wald, q);

TSS = sum((yy - mean(yy)).^2);
out = struct('n',n,'q',q,'b',b(idx),'se',sqrt(diag(V(idx,idx))), ...
             'Wald',Wald,'pWald',pW,'R2', 1 - (u'*u)/TSS);
end

function V = local_nwcov(Z, u, L)
% Newey-West HAC covariance of the OLS coefficient vector.
[n, k] = size(Z);
XtXinv = (Z'*Z) \ eye(k);
S = (Z .* u)' * (Z .* u);                  % lag 0
for l = 1:L
    w  = 1 - l/(L+1);                      % Bartlett weight
    Gl = (Z(l+1:n,:) .* u(l+1:n))' * (Z(1:n-l,:) .* u(1:n-l));
    S  = S + w*(Gl + Gl');
end
V = XtXinv * S * XtXinv;
end
