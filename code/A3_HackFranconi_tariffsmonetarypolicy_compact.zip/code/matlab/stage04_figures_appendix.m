% stage04_figures_appendix.m - Figures B.1, C.1 and D.1 to D.12 of the online appendix
% ------------------------------------------------------------------------------
% Loads the structures saved by stage01 and stage03, builds the local-projection
% structure from the Stata output (code/stata/03_lp.do) and runs the figure
% scripts in makefigs/. Output names follow the manuscript.
% ------------------------------------------------------------------------------
clearvars -except run_mode resume n_workers stata_exec
pkg_settings;
setupfigs;

tData   = readtable(char(pathData + "vardata_trade_clean.xlsx"));
sTariff = loadvar("base");

% Tariff VARs of the appendix -> workspace names used by the figure scripts
sTariffnarrative = loadvar("narrative");
sTariffCEE       = loadvar("CEE");
sTariffPFA       = loadvar("PFA");
sTariffPCA_2     = loadvar("PCA2");
sTariffPCA_4     = loadvar("PCA4");
sTariffPCA_6     = loadvar("PCA6");
sTariffSGUindex  = loadvar("sgu25_traderestrict");
sTariffUnweighted = loadvar("tariffrate_nw");
sTariffSGU1980   = loadvar("sgucomparison1980");
sTariffSGU1967   = loadvar("sgucomparison1967");
sTariffSGU1967nf = loadvar("sgucomparison1967nf");
sTariffadd_tradebalgdp = loadvar("add_tradebalgdp");
sTarifftimetrend2 = loadvar("timetrend2");
sTarifftimetrend3 = loadvar("timetrend3");
sTarifflags6     = loadvar("lags6");
sTarifflags8     = loadvar("lags8");
sTariffcovidc19dummy21q4 = loadvar("covidc19dummy21q4");
for v = 1:12
    eval(sprintf('sTariffbbd_var%d = loadvar("bbd_var%d");', v, v));
end
for v = ["policyrate_ffr_shadow" "policyrate_gs1" "infrate_gr_ppi_nsa" "infrate_gr_cpic" "infrate_infexp_mich1y" ...
         "realactivity_ln_indpro" "realactivity_outputgap" "realactivity_uer" ...
         "add_ln_rpce" "add_ln_rimp_cons" "add_ln_ci20_tpu" "add_ln_ci22_gpr" ...
         "fiscal_ln_rreceipttotal_nd" "fiscal_ln_rgov" "fiscal_ln_rfdebt_sa" "fiscal_ln_rduties"]
    eval(sprintf('sTariff%s = loadvar("%s");', v, v));
end

% Monetary VARs with a single shock (Figure D.9): drop the posterior draws
sMPonlymar = rmfield(loadvar("onlymar"), 'arrIRFdist');
sMPonlyrr  = rmfield(loadvar("onlyrr"),  'arrIRFdist');

% Counterfactuals: s{FFR,INF,GDP}cf<suffix>
pre = {"stabffr", "sFFRcf"; "stabinf", "sINFcf"; "stabgdp", "sGDPcf"};
for k = 1:3
    for suffix = ["base" "onlymar" "onlyrr" "end24" "end07" "rrnew" "j24"]
        if suffix == "base"; vname = pre{k,2}; else; vname = pre{k,2} + suffix; end
        eval(sprintf('%s = loadcf("%s_%s");', vname, pre{k,1}, suffix));
    end
end

%% Local projections (Figure D.5): read the Stata estimates
T = readtable(char(pathResults + "lp_results.csv"));

% variable names from b_* columns (strip the 'b_')
bcols           = startsWith(T.Properties.VariableNames,'b_');
sLP.vVariables  = string(erase(T.Properties.VariableNames(bcols),'b_'));
nVar            = numel(sLP.vVariables);
sLP.H           = height(T);
sLP.arrIRF      = nan(nVar, sDefault.H, 5);  % (var x horizon x band)
sLP.name        = "lp";
sLP.shockname   = "tariffrate";

for i = 1:nVar
    v = sLP.vVariables(i);
    sLP.arrIRF(i,:,1) = T.(sprintf('dn90_%s',v))';  % lowest band
    sLP.arrIRF(i,:,2) = T.(sprintf('dn_%s',v))';    % second-lowest
    sLP.arrIRF(i,:,3) = T.(sprintf('b_%s',v))';     % point estimate
    sLP.arrIRF(i,:,4) = T.(sprintf('up_%s',v))';    % first top band
    sLP.arrIRF(i,:,5) = T.(sprintf('up90_%s',v))';  % very top band
end

%rescaling
factor = 1 / sLP.arrIRF(sLP.vVariables == "tariffrate",1,3);
sLP.arrIRF = sLP.arrIRF * factor;

%% Figures
plot_tariff_figd3;                          % Figure D.3
makefigs_fig_sgu_comparison;                % Figure B.1
makefigs_fig3;                              % Figure C.1
makefigs_fig_app_pca;                       % Figure D.1
makefigs_fig_app_identification;            % Figure D.2
makefigs_fig2;                              % Figure D.4
makefigs_fig_app_varassumptions;            % Figure D.5
makefigs_fig_app_deterministics;            % Figure D.6
makefigs_fig_app_uncertaintymeasures;       % Figure D.7
makefigs_fig_app_additionalvariables;       % Figure D.8
makefigs_fig_app_mpshocks;                  % Figure D.9
makefigs_fig_app_ctft_singleshock_ffrstab;  % Figure D.10, counterfactual 1
makefigs_fig_app_ctft_singleshock_infstab;  %              counterfactual 2
makefigs_fig_app_ctft_singleshock_gdpstab;  %              counterfactual 3
makefigs_fig_app_ctft_sample24_ffrstab;     % Figure D.11
makefigs_fig_app_ctft_sample24_infstab;
makefigs_fig_app_ctft_sample24_gdpstab;
makefigs_fig_app_ctft_sample07_ffrstab;     % Figure D.12
makefigs_fig_app_ctft_sample07_infstab;
makefigs_fig_app_ctft_sample07_gdpstab;
close all;
fprintf('stage04_figures_appendix: Figures B.1, C.1, D.1-D.12 written to results_final/figures\n');
