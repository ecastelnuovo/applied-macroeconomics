% orthogonality_table.m - Table D.1: Forni-Gambetti structuralness test of the tariff shock
% ------------------------------------------------------------------------------
% Regresses the structural tariff shock (at the OLS estimates of the baseline VAR,
% results_interim/shock_tariffrate.mat) on 1-4 lags of the first 4 and 6
% principal components of FRED-QD, extracted on the window 1989Q3-2024Q4 (the
% first two quarters are lost to the transformations). The number of
% components follows the Alessi-Barigozzi-Capasso criterion (printed below)
% and is fixed to 4 and 6 as in the manuscript. Writes the tabular body only.
% Output: results_final/tables/table_d1.tex
% ------------------------------------------------------------------------------
warning('off');

load(char(pathResults + "shock_tariffrate.mat"));       % VARshocks
shock = VARshocks;

% We loose 2 observations in making the series stationary, so choose the
% sample accordingly (2 periods ahead)
startyear  = 1989;
startmonth = 09; % Q3
endyear    = 2024;
endmonth   = 12; % Quarter 4

%% Extract factors
dataFREDMD = readtable(char(pathRaw + "fredqd/fred_qd_2025_05.csv"));
rng('default');
PCextract;
fprintf('orthogonality_table: ABC criterion suggests %d (large window) and %d (small window) components\n', rhat1, rhat2);

p = 4; % lags in the VAR
npc_sel = [4 6]; % first 4 and first 6 PCs (Alessi-Barigozzi-Capasso criterion, as reported in the text)
lags_sel = [1 2 3 4]; % lags of principal components to use

FSTAT_all = zeros(size(npc_sel,2),size(lags_sel,2));
PVALUE_all = zeros(size(npc_sel,2),size(lags_sel,2));

for k = 1:size(lags_sel,2)
    for i = 1: size(npc_sel,2)
        npc = npc_sel(:,i); % PCs to keep
        PCs = score(:, 1:npc); % Extract the first (npc) principal components
        preg = lags_sel(1,k); % lags of the PCs
        x = [lagmaker(PCs(p+1:end,:),preg)]; % we loose the first p lags when estimating the shock in the VAR
        y = shock(1+preg:end,:);
        % Regression of the shock (estimated without PCs) on lags of PCs
        X = [ones(size(x,1),1), x]; % add a constant
        [B,BINT,R,RINT,STATS] = regress(y,X);
        FSTAT_all(i,k) = STATS(:,2);
        PVALUE_all(i,k) = STATS(:,3);
    end
end

disp(["FSTAT = "+ FSTAT_all;"PVALUE = "+ PVALUE_all])

%% Export to Latex (tabular body)
fileID = fopen(char(pathTables + "table_d1.tex"), 'w');

fprintf(fileID, '\t\\begin{tabular}{ccccc|cccc}\n');
fprintf(fileID, '\t\t\\hline \\hline\n');
fprintf(fileID, '\t\t\\multicolumn{1}{c}{} & \\multicolumn{4}{c}{First 4 PCs, $k$ lags} & \\multicolumn{4}{c}{First 6 PCs, $k$ lags}   \\\\\n');
fprintf(fileID, '\t\t& $k=1$               & $k=2$               & $k=3$               & $k=4$       & $k=1$               & $k=2$               & $k=3$               & $k=4$      \\\\ \\cline{2-9} \n');

% Write F-statistics row
fprintf(fileID, '\t\t$F$-stat           & %.3f & %.3f & %.3f & %.3f & %.3f & %.3f & %.3f & %.3f \\\\\n', ...
    FSTAT_all(1,1), FSTAT_all(1,2), FSTAT_all(1,3), FSTAT_all(1,4), FSTAT_all(2,1), FSTAT_all(2,2), FSTAT_all(2,3), FSTAT_all(2,4));

% Write p-values row
fprintf(fileID, '\t\t$p$-value        & %.3f & %.3f & %.3f & %.3f & %.3f & %.3f & %.3f & %.3f \\\\\n', ...
    PVALUE_all(1,1), PVALUE_all(1,2), PVALUE_all(1,3), PVALUE_all(1,4), PVALUE_all(2,1), PVALUE_all(2,2), PVALUE_all(2,3), PVALUE_all(2,4));

% Write the end of the table
fprintf(fileID, '\t\t\\hline \\hline\n');
fprintf(fileID, '\t\\end{tabular}\n');

fclose(fileID);
disp('orthogonality_table: LaTeX table written to results_final/tables/table_d1.tex');
