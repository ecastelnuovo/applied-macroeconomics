% stage06_numbers_in_text.m - numbers cited in the manuscript text
% ------------------------------------------------------------------------------
% Prints, in text order, the empirical numbers the manuscript cites that cannot
% be read off a table, recomputed from the saved structures of this package
% (posterior medians). Runs last; in run_mode "maintext" only the main-text
% items are printed. Output: results_final/numbers_in_text.txt
% ------------------------------------------------------------------------------
clearvars -except run_mode resume n_workers stata_exec
pkg_settings;

tData   = readtable(char(pathData + "vardata_trade_clean.xlsx"));
sTariff = loadvar("base");
sFFRcf  = loadcf("stabffr_base");
sINFcf  = loadcf("stabinf_base");
sGDPcf  = loadcf("stabgdp_base");

fid = fopen(char("../../results_final/numbers_in_text.txt"), 'w');
out = @(varargin) fprintf(fid, varargin{:});
med = @(s, v) squeeze(s.arrIRF(find(s.vVariables == v, 1), 1:s.H, 3));      % posterior median, h = 0..H-1
lo68 = @(s, v) squeeze(s.arrIRF(find(s.vVariables == v, 1), 1:s.H, 2));
hi68 = @(s, v) squeeze(s.arrIRF(find(s.vVariables == v, 1), 1:s.H, 4));
lo90 = @(s, v) squeeze(s.arrIRF(find(s.vVariables == v, 1), 1:s.H, 1));
hi90 = @(s, v) squeeze(s.arrIRF(find(s.vVariables == v, 1), 1:s.H, 5));
h = 0:sTariff.H-1;
n = 0;
claim = @(k, loc, txt) fprintf(fid, '\n[%d] %s\n    TEXT:   %s\n', k, loc, txt);

out('Numbers cited in the manuscript text, recomputed from the package (%s)\n', datestr(now, 'yyyy-mm-dd'));
out('Values are posterior medians of the baseline tariff VAR and its counterfactuals;\n');
out('horizons h in quarters after the shock (h = 0 is the impact quarter).\n');

%% --- Baseline responses (Section 4.1; also abstract and introduction) ------------
out('\n%s\nBASELINE TARIFF VAR (Figure 2)\n%s\n', repmat('-',1,90), repmat('-',1,90));

n = n+1; claim(n, 'Sec. 1 / Sec. 4.1', 'a tariff shock ... leads to a significantly elevated tariff rate for about 3 years');
m = med(sTariff, "tariffrate"); l = lo68(sTariff, "tariffrate"); l9 = lo90(sTariff, "tariffrate");
out('    tariff rate: last h with 68%% set above zero = %d, with 90%% set above zero = %d (years: %.2f, %.2f)\n', ...
    find(l > 0, 1, 'last') - 1, find(l9 > 0, 1, 'last') - 1, (find(l > 0, 1, 'last') - 1)/4, (find(l9 > 0, 1, 'last') - 1)/4);

n = n+1; claim(n, 'Sec. 4.1, "Core outcomes" (and Sec. 1)', 'Inflation ... peaks at 0.78 percentage points after 11 quarters');
m = med(sTariff, "gr_cpi"); [pk, ih] = max(m);
out('    CPI inflation: peak %.4f pp at h = %d\n', pk, h(ih));

n = n+1; claim(n, 'Sec. 4.1', 'the 68% credible set includes zero only after 17 quarters');
l = lo68(sTariff, "gr_cpi");
out('    CPI inflation: first h after the peak with 68%% lower band <= 0: %d\n', h(find(l(ih:end) <= 0, 1) + ih - 1));

n = n+1; claim(n, 'Sec. 4.1 (and Sec. 1)', 'The trough [of real GDP] is reached 6 quarters after the shock, at which output is 1.23% lower');
m = med(sTariff, "ln_rgdp"); [tr, it] = min(m);
out('    real GDP: trough %.4f %% at h = %d\n', tr, h(it));

n = n+1; claim(n, 'Sec. 4.1', 'This decline ... vanishes after the second year, when even the 68% credible set contains zero');
u = hi68(sTariff, "ln_rgdp");
out('    real GDP: first h after the trough with 68%% upper band >= 0: %d\n', h(find(u(it:end) >= 0, 1) + it - 1));

n = n+1; claim(n, 'Sec. 4.1', 'at the trough, the FFR is 0.85 percentage points lower after 6 quarters');
m = med(sTariff, "ffr"); [tr, it] = min(m);
out('    FFR: trough %.4f pp at h = %d\n', tr, h(it));

%% --- Counterfactuals (Section 4.2; also abstract and introduction) ---------------
out('\n%s\nMONETARY POLICY COUNTERFACTUALS (Figure 3)\n%s\n', repmat('-',1,90), repmat('-',1,90));
b_gdp = med(sTariff, "ln_rgdp"); b_inf = med(sTariff, "gr_cpi"); b_ffr = med(sTariff, "ffr");
[b_inf_pk, b_inf_ih] = max(b_inf); [b_gdp_tr, b_gdp_it] = min(b_gdp);

n = n+1; claim(n, 'Sec. 4.2, "No interest rate response"', 'Real GDP is broadly unaffected by this alternative monetary response for around 4 quarters');
c_gdp = med(sFFRcf, "ln_rgdp");
out('    |GDP cfct - baseline| by h: %s\n', sprintf('%.3f ', abs(c_gdp(1:9) - b_gdp(1:9))));

n = n+1; claim(n, 'Sec. 4.2, "No interest rate response"', 'a peak inflation effect that is 14% (0.11 percentage points) lower');
c_inf = med(sFFRcf, "gr_cpi"); [c_pk, c_ih] = max(c_inf);
out('    peak inflation: baseline %.4f (h=%d), no-FFR-response %.4f (h=%d); difference %.4f pp = %.1f %%\n', ...
    b_inf_pk, h(b_inf_ih), c_pk, h(c_ih), c_pk - b_inf_pk, (c_pk - b_inf_pk) / b_inf_pk * 100);

n = n+1; claim(n, 'Sec. 4.2, "Strict inflation stabilization" (and Sec. 1)', 'a short-lived interest rate hike that peaks at 0.83 percentage points only 1 quarter after the shock');
c_ffr = med(sINFcf, "ffr"); [pk, ih] = max(c_ffr);
out('    FFR under inflation stabilization: peak %.4f pp at h = %d\n', pk, h(ih));

n = n+1; claim(n, 'Sec. 4.2 (and Sec. 1)', 'peak inflation reduced from 0.78 to only 0.22 percentage points ... baseline inflation response in the same quarter is almost four times larger');
c_inf = med(sINFcf, "gr_cpi"); [pk, ih] = max(c_inf);
out('    inflation under inflation stabilization: peak %.4f pp at h = %d; baseline at that h %.4f (ratio %.2f)\n', pk, h(ih), b_inf(ih), b_inf(ih)/pk);

n = n+1; claim(n, 'Sec. 4.2 (and abstract, Sec. 1)', 'The counterfactual GDP trough is 0.44 percentage points lower than the baseline. This represents a 36% increase');
c_gdp = med(sINFcf, "ln_rgdp"); [tr, it] = min(c_gdp);
out('    GDP trough: baseline %.4f (h=%d), inflation stabilization %.4f (h=%d); difference %.4f pp = %.1f %%\n', ...
    b_gdp_tr, h(b_gdp_it), tr, h(it), tr - b_gdp_tr, (tr - b_gdp_tr) / b_gdp_tr * 100);

n = n+1; claim(n, 'Sec. 4.2', 'it takes 16 quarters for the counterfactual response to catch up with the baseline');
d = c_gdp - b_gdp;
out('    GDP cfct - baseline by h: %s\n    first h after the trough with cfct >= baseline: %d\n', sprintf('%.3f ', d), h(find(d(it:end) >= 0, 1) + it - 1));

n = n+1; claim(n, 'Sec. 4.2, "Strict output stabilization" (and Sec. 1)', 'a peak interest rate cut of about 2 percentage points reached only 1 quarter after the tariff shock (Sec. 1: trough -2.0)');
c_ffr = med(sGDPcf, "ffr"); [tr, it] = min(c_ffr);
out('    FFR under output stabilization: trough %.4f pp at h = %d\n', tr, h(it));

n = n+1; claim(n, 'Sec. 4.2 (and abstract, Sec. 1)', 'the peak inflation effect roughly doubles compared with the baseline (an increase of 0.93 percentage points)');
c_inf = med(sGDPcf, "gr_cpi"); [pk, ih] = max(c_inf);
out('    peak inflation: baseline %.4f (h=%d), output stabilization %.4f (h=%d); increase %.4f pp, ratio %.2f\n', ...
    b_inf_pk, h(b_inf_ih), pk, h(ih), pk - b_inf_pk, pk / b_inf_pk);

%% --- Data facts ---------------------------------------------------------------------
out('\n%s\nDATA FACTS\n%s\n', repmat('-',1,90), repmat('-',1,90));
n = n+1; claim(n, 'Sec. 2.1 / Sec. 3.3', 'baseline sample 1990Q1-2024Q4; 20,000 posterior draws; lag order p = 4');
out('    baseline: sample %s to %s, draws %d, lags %d, variables: %s\n', sTariff.vSample(1), sTariff.vSample(2), sTariff.estimator.nd, sTariff.lags, strjoin(sTariff.vVariables(1:end-1), ", "));

n = n+1; claim(n, 'Sec. 2.1, FN 1', 'dutiable imports = goods imports x the average share of dutiable goods (USITC DataWeb)');
out('    the share constant is printed in the Stata log of stage 2 (results_interim/stata_prep.log): "dutiableimportshare"\n');

n = n+1; claim(n, 'Sec. 3.3', 'MP VAR sample 1969Q1-2014Q4; MAR shock available 1980Q1-2014Q4, RR shock 1969Q1-2007Q4');
sMP = loadvar("basemp");
dq = tData.DATE_Q;
nz = @(v) dq(tData.(v) ~= 0 & ~isnan(tData.(v)));
out('    MP VAR sample %s to %s; mp_mar non-zero %s to %s; mp_rr non-zero %s to %s\n', sMP.vSample(1), sMP.vSample(2), ...
    datestr(min(nz("mp_mar")), 'yyyyQQ'), datestr(max(nz("mp_mar")), 'yyyyQQ'), datestr(min(nz("mp_rr")), 'yyyyQQ'), datestr(max(nz("mp_rr")), 'yyyyQQ'));

n = n+1; claim(n, 'App. B', '1967Q1 is the earliest feasible sample start (terms-of-trade index available from 1967)');
out('    ln_totindex_npgood first non-zero quarter: %s\n', datestr(min(nz("ln_totindex_npgood")), 'yyyyQQ'));

n = n+1; claim(n, 'Sec. 2.2 / App. D', '14 narratively identified tariff policy events');
out('    quarters with tariffnarr_shock ~= 0: %d\n', nnz(tData.tariffnarr_shock(dq >= datetime(1990,1,1))));

if run_mode == "full"
    out('\n%s\nONLINE APPENDIX\n%s\n', repmat('-',1,90), repmat('-',1,90));
    n = n+1; claim(n, 'App. D.1', 'the SPF regressions use 136 observations; the Forni-Gambetti test uses 4 and 6 components (ABC criterion)');
    out('    see results_final/tables/table_d2.tex (Observations row) and the stage-5 log (ABC criterion line)\n');
end

fclose(fid);
fprintf('stage06_numbers_in_text: %d items written to results_final/numbers_in_text.txt\n', n);
