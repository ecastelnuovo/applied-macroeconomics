% stage02_figures_maintext.m - Figures 1 to 4 of the main text
% ------------------------------------------------------------------------------
% Loads the structures saved by stage01_estimate_core.m and runs the figure
% scripts in makefigs/. Output names follow the manuscript
% (results_final/figures/figure_<n>_panel_<letter>.pdf).
% ------------------------------------------------------------------------------
clearvars -except run_mode resume n_workers stata_exec
pkg_settings;
setupfigs;

tData   = readtable(char(pathData + "vardata_trade_clean.xlsx"));
sTariff = loadvar("base");
sFFRcf  = loadcf("stabffr_base");
sINFcf  = loadcf("stabinf_base");
sGDPcf  = loadcf("stabgdp_base");

plot_tariff_fig1;        % Figure 1
makefigs_fig1_new;       % Figure 2
makefigs_fig4_fig5;      % Figures 3 and 4
close all;
fprintf('stage02_figures_maintext: Figures 1-4 written to results_final/figures\n');
