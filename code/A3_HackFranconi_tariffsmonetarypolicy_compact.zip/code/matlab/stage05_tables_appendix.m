% stage05_tables_appendix.m - Tables D.1 and D.2 of the online appendix
% ------------------------------------------------------------------------------
% Table D.1: orthogonality_table.m (structuralness test, from the saved shock
%            and the FRED-QD components)
% Table D.2: spf_granger_table.m (SPF net-export forecasts vs the shock)
% ------------------------------------------------------------------------------
clearvars -except run_mode resume n_workers stata_exec
pkg_settings;

tData   = readtable(char(pathData + "vardata_trade_clean.xlsx"));
sTariff = loadvar("base");

orthogonality_table;      % Table D.1
spf_granger_table;        % Table D.2
fprintf('stage05_tables_appendix: Tables D.1 and D.2 written to results_final/tables\n');
