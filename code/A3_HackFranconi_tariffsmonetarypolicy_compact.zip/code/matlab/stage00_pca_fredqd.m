% stage00_pca_fredqd.m - principal components of the FRED-QD data set
% ------------------------------------------------------------------------------
% Extracts the principal components of the transformed FRED-QD panel
% (McCracken and Ng, 2020; vintage 2025-05) on 1988Q3-2024Q4 with
% auxfiles/PCextract.m; the transformations lose the first two quarters, so
% the components cover 1989Q1-2024Q4. The Stata stage merges PC1-PC6 into the
% VAR data set (Figure D.1). Table D.1 recomputes the components on its own
% window in stage05_tables_appendix.m.
% Input : rawdata/fredqd/fred_qd_2025_05.csv
% Output: results_interim/fredqd_pca.csv  (qdate, pc1 ... pc6)
% ------------------------------------------------------------------------------
clearvars -except run_mode resume n_workers stata_exec
pkg_settings;
warning('off');

dataFREDMD = readtable(char(pathRaw + "fredqd/fred_qd_2025_05.csv"));
startyear  = 1988; startmonth = 9;      % first quarter kept after the transformations: 1989Q1
endyear    = 2024; endmonth   = 12;
PCextract;                              % -> score (T x N), timestr_data (dates, first two dropped)

dates = timestr_data(3:end);
fid = fopen(char(pathResults + "fredqd_pca.csv"), 'w');
fprintf(fid, 'qdate,pc1,pc2,pc3,pc4,pc5,pc6\n');
for t = 1:numel(dates)
    fprintf(fid, '%s', datestr(dates(t), 'yyyy-mm-dd'));
    fprintf(fid, ',%.17g', score(t, 1:6));
    fprintf(fid, '\n');
end
fclose(fid);
fprintf('stage00_pca_fredqd: %d quarters (%s to %s), %d series, PC1-PC6 written to results_interim/fredqd_pca.csv\n', ...
    numel(dates), datestr(dates(1), 'yyyy-mm-dd'), datestr(dates(end), 'yyyy-mm-dd'), size(score, 2));
