function fn = exhibit_path(figid, v, row)
% exhibit_path - file name of a figure panel under manuscript numbering
% ------------------------------------------------------------------------------
% fn = exhibit_path(figid, v [, row]) returns the pdf path (in
% results_final/figures) of the panel showing variable v in figure figid, or
% "" when the manuscript does not show that panel. Panel letters follow the
% order of the panels in the manuscript.
% ------------------------------------------------------------------------------
pathFigures = "../../results_final/figures/";
std10 = ["tariffrate" "gr_cpi" "ln_rgdp" "ffr" "ln_rexp" "ln_rimp" "ln_totindex_npgood" "ln_rinv" "ln_uncert_macroh12" "tradebalance"];
letters = ["a" "b" "c" "d" "e" "f" "g" "h" "i" "j" "k" "l" "m" "n" "o" "p"];
if nargin < 3; row = 1; end
switch figid
    case "fig1";  fn = pathFigures + "figure_1.pdf"; return
    case "figd3"; fn = pathFigures + "figure_d3.pdf"; return
    case "fig2";  vars = std10(1:9);                       name = "figure_2";
    case "fig3";  vars = ["gr_cpi" "ln_rgdp" "ffr"];       name = "figure_3";   % rows: cf 1-3
    case "fig4";  vars = ["ln_uncert_macroh12" "ln_rinv" "ln_totindex_npgood" "tradebalance"]; name = "figure_4";
    case "figb1"; vars = std10; name = "figure_b1";
    case "figc1"; vars = ["ln_rduties" "ln_rgov" "ln_rreceipttotal_nd" "ln_rfdebt_sa" "ln_rpce" "ln_rimp_cons" "tradebalance" "tradebalgdp" ...
                          "uer" "outputgap" "ln_indpro" "gr_ppi_nsa" "gr_cpic" "infexp_mich1y" "ffr_shadow" "gs1"]; name = "figure_c1";
    case "figd1"; vars = std10; name = "figure_d1";
    case "figd2"; vars = std10; name = "figure_d2";
    case "figd4"; vars = ["sgu25_traderestrict" std10(2:10)]; name = "figure_d4";
    case "figd5"; vars = std10; name = "figure_d5";
    case "figd6"; vars = std10; name = "figure_d6";
    case "figd7"; vars = std10; name = "figure_d7";
    case "figd8"; vars = std10; name = "figure_d8";
    case "figd9"; vars = std10; name = "figure_d9";
    case {"figd10", "figd11", "figd12"}; vars = std10; name = "figure_" + extractAfter(figid, "fig") + "_cf" + row;
    otherwise; error("exhibit_path: unknown figure id %s", figid);
end
idx = find(vars == v, 1);
if isempty(idx); fn = ""; return; end
if figid == "fig3" || figid == "fig4"
    idx = (row - 1) * numel(vars) + idx;      % letters run across the three counterfactual rows
end
fn = pathFigures + name + "_panel_" + letters(idx) + ".pdf";
end
