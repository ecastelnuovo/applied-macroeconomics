% stage03_estimate_appendix.m - all VARs and counterfactuals of the online appendix
% ------------------------------------------------------------------------------
% Estimates every VAR and counterfactual of the online appendix (Figures B.1,
% C.1, D.1, D.2, D.4-D.12). Every estimated structure is saved to results_interim/ as
% var_<name>.mat (tariff and monetary VARs) or cf_<name>.mat (counterfactuals);
% with resume = true, saved structures are reused.
% Input : data/vardata_trade_clean.xlsx, results_interim/var_base.mat
% ------------------------------------------------------------------------------
clearvars -except run_mode resume n_workers stata_exec
pkg_settings;
if isempty(gcp('nocreate')); parpool('local', n_workers); end
tData   = readtable(char(pathData + "vardata_trade_clean.xlsx"));
sTariff = loadvar("base");
tstage  = tic;

% Estimation helpers shared by the blocks below (store without posterior draws)
estimate_save = @(s, key) savevar(key, rmfield(add_tradebalance(fVARestimation(s, tData), tData), 'arrIRFdist'));

%% Tariff VAR: Identification robustness: Narrative IV (Figure D.2)
if ~havevar("narrative")
    sTariffnarrative         = sDefault;
    sTariffnarrative.name    = "narrative";
    sTariffnarrative.Exovar  = "tariffnarr_shock"; 
    sTariffnarrative.shocktype = "exo";
    sTariffnarrative.scalingfactor = 1;
    sTariffnarrative = fVARestimation_ext(sTariffnarrative, tData);
    sTariffnarrative = add_tradebalance(sTariffnarrative, tData);
    savevar("narrative", rmfield(sTariffnarrative, 'arrIRFdist'));
    fprintf('stage03: narrative done (%.0f s)\n', toc(tstage));
end

%% Tariff VAR: Identification robustness: CEE type ordering (Figure D.2)
if ~havevar("CEE")
    sTariffCEE         = sDefault;
    sTariffCEE.name    = "CEE";
    % Adjust ordering (implict assumption that fast variables are at the
    % beginning and last "fast" variable is gr_cpi)
    ind_cpi                 = find(strcmp(sTariffCEE.vVariables, "gr_cpi")); 
    sTariffCEE.vVariables   = [setdiff(sTariffCEE.vVariables, sTariffCEE.vVariables(1:ind_cpi),'stable'), intersect(sTariffCEE.vVariables, sTariffCEE.vVariables(1:ind_cpi),'stable')];
    sTariffCEE.vShockPos    = sTariffCEE.vShockPos - ind_cpi;
    estimate_save(sTariffCEE, "CEE");
    fprintf('stage03: CEE done (%.0f s)\n', toc(tstage));
end

%% Tariff VAR: Penalty Function Approach (Figure D.2)
if ~havevar("PFA")
    sTariffPFA         = sDefault;
    sTariffPFA.name    = "PFA";
    % Perturb ordering    
    sTariffPFA.vVariables = [sTariffPFA.shockname, setdiff(sTariffPFA.vVariables, sTariffPFA.shockname,'stable')];
    sTariffPFA.vShockPos  = find(contains(sTariffPFA.vVariables, sTariffPFA.shockname));
    sTariffPFA.penalty.nper    = 4;   % maximization horizon of the PFA (4 quarters: first year)
    sTariffPFA = fVARestimation_penalty(sTariffPFA, tData);
    sTariffPFA = add_tradebalance(sTariffPFA, tData);
    savevar("PFA", rmfield(sTariffPFA, 'arrIRFdist'));
    fprintf('stage03: PFA done (%.0f s)\n', toc(tstage));
end

%% Tariff VAR: Identification robustness: include PCs (Figure D.1)
for v = 2:2:6
    key = strcat("PCA", num2str(v));
    if havevar(key); continue; end
    sTariffTemp             = sDefault;
    sTariffTemp.name        = key;
    for i = 1:v
        sTariffTemp.vVariables = [sTariffTemp.vVariables, strcat("PC", num2str(i))];
    end
    estimate_save(sTariffTemp, key);
    fprintf('stage03: %s done (%.0f s)\n', key, toc(tstage));
end

%% Tariff VAR: Tariff measurement robustness: SGU index and unweighted rate (Figure D.4)
for v = ["sgu25_traderestrict" "tariffrate_nw"]
    if havevar(v); continue; end
    sTariffTemp         = sDefault;
    sTariffTemp.name    = v;
    sTariffTemp.vVariables(strcmp(sTariffTemp.vVariables, sDefault.shockname)) = v;
    sTariffTemp.shockname = v;
    estimate_save(sTariffTemp, v);
    fprintf('stage03: %s done (%.0f s)\n', v, toc(tstage));
end

%% Tariff VAR: Comparison with SGU: sample starts 1980 and 1967, 1967 without the Nixon/Ford spikes (Figure B.1)
if ~havevar("sgucomparison1980")
    sTariffSGU1980         = sDefault;
    sTariffSGU1980.name    = "sgucomparison1980";
    sTariffSGU1980.vSample = ["1980-01-01", "2024-10-01"];
    estimate_save(sTariffSGU1980, "sgucomparison1980");
    fprintf('stage03: sgucomparison1980 done (%.0f s)\n', toc(tstage));
end
if ~havevar("sgucomparison1967")
    sTariffSGU1967         = sDefault;
    sTariffSGU1967.name    = "sgucomparison1967";
    sTariffSGU1967.vSample = ["1967-01-01", "2024-10-01"];
    estimate_save(sTariffSGU1967, "sgucomparison1967");
    fprintf('stage03: sgucomparison1967 done (%.0f s)\n', toc(tstage));
end
if ~havevar("sgucomparison1967nf")
    sTariffSGU1967nf         = sDefault;
    sTariffSGU1967nf.name    = "sgucomparison1967nf";
    sTariffSGU1967nf.vSample = ["1967-01-01", "2024-10-01"];
    % Below uses tariffvariable that smoothes out Nixon and Ford shock: tariffrate_nf
    sTariffSGU1967nf.vVariables(8) = "tariffrate_nf";
    sTariffSGU1967nf.shockname = sTariffSGU1967nf.vVariables(8);
    estimate_save(sTariffSGU1967nf, "sgucomparison1967nf");
    fprintf('stage03: sgucomparison1967nf done (%.0f s)\n', toc(tstage));
end

%% Tariff VAR: include tradebalance-to-gdp instead of imports exports (Figure C.1, panel h)
if ~havevar("add_tradebalgdp")
    sTariffadd_tradebalgdp             = sDefault;
    sTariffadd_tradebalgdp.name        = "tradebalance";
    sTariffadd_tradebalgdp.vVariables  = ["tradebalgdp" setdiff(sTariffadd_tradebalgdp.vVariables, ["ln_rimp" "ln_rexp"],'stable')];
    sTariffadd_tradebalgdp.vShockPos   = sTariffadd_tradebalgdp.vShockPos - 1;
    sTariffadd_tradebalgdp = fVARestimation(sTariffadd_tradebalgdp, tData);
    savevar("add_tradebalgdp", rmfield(sTariffadd_tradebalgdp, 'arrIRFdist'));
    fprintf('stage03: add_tradebalgdp done (%.0f s)\n', toc(tstage));
end

%% Tariff VAR: Timetrend robustness (Figure D.6)
for v = 2:3
    key = strcat("timetrend", string(v));
    if havevar(key); continue; end
    sTariffTemp                 = sDefault;
    sTariffTemp.detpolynorder   = v;
    sTariffTemp.name            = key;
    estimate_save(sTariffTemp, key);
    fprintf('stage03: %s done (%.0f s)\n', key, toc(tstage));
end

%% Tariff VAR: lag order (Figure D.5)
for v = [6 8]
    key = strcat("lags", string(v));
    if havevar(key); continue; end
    sTariffTemp                 = sDefault;
    sTariffTemp.lags            = v;
    sTariffTemp.name            = key;
    estimate_save(sTariffTemp, key);
    fprintf('stage03: %s done (%.0f s)\n', key, toc(tstage));
end

%% Tariff VAR: covid dummy 2020Q1-2021Q4 (Figure D.6)
if ~havevar("covidc19dummy21q4")
    sTariffTemp                 = sDefault;
    sTariffTemp.Exovar          = "c19dummy21q4";
    sTariffTemp.name            = strcat("covid", sTariffTemp.Exovar);
    estimate_save(sTariffTemp, "covidc19dummy21q4");
    fprintf('stage03: covidc19dummy21q4 done (%.0f s)\n', toc(tstage));
end

%% Tariff VAR: control for policy uncertainty (Figure D.7)
vars = tData.Properties.VariableNames;
bbdVars = vars(startsWith(vars, 'ln_bbd16'));
for v = 1:length(bbdVars)
    key = strcat("bbd_var", num2str(v));
    if havevar(key); continue; end
    sTariffTemp                 = sDefault;
    sTariffTemp.vVariables      = [sTariffTemp.vVariables bbdVars(v)];
    sTariffTemp.name            = key;
    estimate_save(sTariffTemp, key);
    fprintf('stage03: %s (%s) done (%.0f s)\n', key, bbdVars{v}, toc(tstage));
end

%% Tariff VAR: Alternative policy rates (Figure C.1, panels o-p)
for v = ["ffr_shadow" "gs1"]
    key = strcat("policyrate_", v);
    if havevar(key); continue; end
    sTariffTemp             = sDefault;
    sTariffTemp.name        = key;
    sTariffTemp.vVariables(strcmp(sTariffTemp.vVariables, "ffr")) = v;
    estimate_save(sTariffTemp, key);
    fprintf('stage03: %s done (%.0f s)\n', key, toc(tstage));
end
    
%% Tariff VAR: Alternative inflation rates (Figure C.1, panels l-n)
for v = ["gr_ppi_nsa" "gr_cpic" "infexp_mich1y"]
    key = strcat("infrate_", v);
    if havevar(key); continue; end
    sTariffTemp             = sDefault;
    sTariffTemp.name        = key;
    sTariffTemp.vVariables(strcmp(sTariffTemp.vVariables, "gr_cpi")) = v;
    estimate_save(sTariffTemp, key);
    fprintf('stage03: %s done (%.0f s)\n', key, toc(tstage));
end
    
%% Tariff VAR: Alternative real activity measures (Figure C.1, panels i-k)
for v = ["ln_indpro" "outputgap" "uer"]
    key = strcat("realactivity_", v);
    if havevar(key); continue; end
    sTariffTemp             = sDefault;
    sTariffTemp.name        = key;
    sTariffTemp.vVariables(strcmp(sTariffTemp.vVariables, "ln_rgdp")) = v;
    estimate_save(sTariffTemp, key);
    fprintf('stage03: %s done (%.0f s)\n', key, toc(tstage));
end

%% Tariff VAR: Additional variables ordered before the tariff rate (Figure C.1, panels e-f)
for v = ["ln_rpce" "ln_rimp_cons"] 
    key = strcat("add_", v);
    if havevar(key); continue; end
    sTariffTemp             = sDefault;
    sTariffTemp.name        = key;
    sTariffTemp.vVariables = [v sTariffTemp.vVariables];
    sTariffTemp.vShockPos  = sTariffTemp.vShockPos + 1;
    sTariffTemp = fVARestimation(sTariffTemp, tData);
    sTariffTemp = add_tradebalance(sTariffTemp, tData);
    savevar(key, rmfield(sTariffTemp, 'arrIRFdist'));
    fprintf('stage03: %s done (%.0f s)\n', key, toc(tstage));
end    

%% Tariff VAR: Additional variables ordered last (Figure D.7)
for v = ["ln_ci20_tpu" "ln_ci22_gpr" ] 
    key = strcat("add_", v);
    if havevar(key); continue; end
    sTariffTemp             = sDefault;
    sTariffTemp.name        = key;
    sTariffTemp.vVariables = [sTariffTemp.vVariables v];
    estimate_save(sTariffTemp, key);
    fprintf('stage03: %s done (%.0f s)\n', key, toc(tstage));
end    

%% Tariff VAR: Augmented by fiscal variables (Figure C.1, panels a-d)
% Variables ordered before the tariff rate
for v = ["ln_rreceipttotal_nd" "ln_rgov" "ln_rfdebt_sa" ]
    key = strcat("fiscal_", v);
    if havevar(key); continue; end
    sTariffTemp             = sDefault;
    sTariffTemp.name        = key;
    sTariffTemp.vVariables = [v sTariffTemp.vVariables];
    sTariffTemp.vShockPos  = sTariffTemp.vShockPos + 1;
    sTariffTemp = fVARestimation(sTariffTemp, tData);
    sTariffTemp = add_tradebalance(sTariffTemp, tData);
    savevar(key, rmfield(sTariffTemp, 'arrIRFdist'));
    fprintf('stage03: %s done (%.0f s)\n', key, toc(tstage));
end    
% Duties ordered after the tariff rate
if ~havevar("fiscal_ln_rduties")
    sTarifffiscal_ln_rduties         = sDefault;
    sTarifffiscal_ln_rduties.name    = "fiscal_ln_rduties";
    sTarifffiscal_ln_rduties.vVariables    = [sTarifffiscal_ln_rduties.vVariables "ln_rduties"];
    sTarifffiscal_ln_rduties = fVARestimation(sTarifffiscal_ln_rduties, tData);
    sTarifffiscal_ln_rduties = add_tradebalance(sTarifffiscal_ln_rduties, tData);
    savevar("fiscal_ln_rduties", rmfield(sTarifffiscal_ln_rduties, 'arrIRFdist'));
    fprintf('stage03: fiscal_ln_rduties done (%.0f s)\n', toc(tstage));
end

%% Monetary VARs for the appendix counterfactuals (Figures D.9-D.12)
% name, shocks, sample; posterior draws are kept (needed by the counterfactuals)
mpspecs = {
    "onlymar", "mp_mar",                ["1969-01-01", "2014-10-01"], "single_mar"
    "onlyrr",  "mp_rr",                 ["1969-01-01", "2014-10-01"], "single_rr"
    "end24",   ["mp_mar" "mp_rr"],      ["1969-01-01", "2024-10-01"], "two"
    "end07",   ["mp_mar" "mp_rr"],      ["1969-01-01", "2007-10-01"], "two"
    "j24",     ["mp_j24_u1" "mp_rr"],   ["1969-01-01", "2024-10-01"], "two"
    "rrnew",   ["mp_mar" "mp_rr_new"],  ["1969-01-01", "2007-10-01"], "two"};
idx_ffr = find(strcmp(sDefault.vVariables, "ffr"));
for k = 1:size(mpspecs, 1)
    key = mpspecs{k,1};
    if havevar(key); continue; end
    s                 = sDefault;
    s.name            = key;
    s.idx_ffr         = idx_ffr;
    s.shockname       = mpspecs{k,2};
    switch mpspecs{k,4}
        case "single_mar"   % MAR shock ordered first, RR shock kept in the vector, IRFs to MAR only
            s.vVariables = ["mp_mar", sDefault.vVariables(1:idx_ffr-1), "mp_rr", sDefault.vVariables(idx_ffr:end)];
            s.vShockPos  = find(strcmp(s.vVariables, "mp_mar"));
        case "single_rr"    % IRFs to RR only
            s.vVariables = ["mp_mar", sDefault.vVariables(1:idx_ffr-1), "mp_rr", sDefault.vVariables(idx_ffr:end)];
            s.vShockPos  = find(strcmp(s.vVariables, "mp_rr"));
        case "two"
            s.vVariables = [s.shockname(1), sDefault.vVariables(1:idx_ffr-1), s.shockname(2), sDefault.vVariables(idx_ffr:end)];
            s.vShockPos  = [find(strcmp(s.vVariables, s.shockname(1))), find(strcmp(s.vVariables, s.shockname(2)))];
    end
    s.vSample         = mpspecs{k,3};
    s.missingzero     = true;
    s.scalingfactor   = ""; % empty: no normalisation needed
    s = fVARestimation(s, tData);
    s = add_tradebalance(s, tData);
    savevar(key, s);
    fprintf('stage03: monetary VAR %s done (%.0f s)\n', key, toc(tstage));
end

%% Counterfactuals with the alternative monetary VARs (Figures D.10-D.12)
targets = {"ffr", "stabffr"; "gr_cpi", "stabinf"; "ln_rgdp", "stabgdp"};
for k = 1:size(mpspecs, 1)
    suffix = mpspecs{k,1};
    need = false;
    for j = 1:3; need = need || ~havecf(targets{j,2} + "_" + suffix); end
    if ~need; continue; end
    sMPalt = loadvar(suffix);
    for j = 1:3
        name = targets{j,2} + "_" + suffix;
        if havecf(name); continue; end
        sCF         = sDefaultcf;
        sCF.target  = targets{j,1};
        sCF.name    = name;
        sCF = fVARcfct(sTariff, sMPalt, sCF);
        savecf(name, rmfield(sCF, 'arrIRFdist'));
    end
    clear sMPalt
    fprintf('stage03: counterfactuals %s done (%.0f s)\n', suffix, toc(tstage));
end

fprintf('stage03_estimate_appendix: all appendix estimates saved (%.0f s)\n', toc(tstage));
