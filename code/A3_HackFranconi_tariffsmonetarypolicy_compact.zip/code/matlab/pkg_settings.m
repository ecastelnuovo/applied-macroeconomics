% pkg_settings.m - shared settings of all MATLAB stages (run from package/code/matlab)
% ------------------------------------------------------------------------------
% Defines paths, the default VAR and counterfactual setups, the parallel-pool
% helper and the save/load helpers for estimation results. Every stage script
% calls it first.
% ------------------------------------------------------------------------------
if exist('run_mode', 'var') ~= 1;  run_mode  = "full"; end   % "full" or "maintext"
if exist('resume', 'var') ~= 1;    resume    = false;  end   % reuse saved estimates
if exist('n_workers', 'var') ~= 1; n_workers = 4;      end   % parallel workers

set(groot, 'DefaultFigureVisible', 'off');
warning('off', 'MATLAB:table:ModifiedAndSavedVarnames');
rng('default');
addpath('auxfiles/');
addpath('makefigs/');

pathRaw     = "../../rawdata/";
pathData    = "../../data/";
pathResults = "../../results_interim/";
pathFigures = "../../results_final/figures/";
pathTables  = "../../results_final/tables/";
if ~exist(pathResults, 'dir'); mkdir(pathResults); end
if ~exist(pathFigures, 'dir'); mkdir(pathFigures); end
if ~exist(pathTables, 'dir');  mkdir(pathTables);  end

vPercentiles = [5 16 50 84 95];

% Default VAR setup
sDefault.CEEordering     = false; 
sDefault.datevar         = "DATE_Q";    
sDefault.vVariables      = ["ln_uncert_macroh12", "ln_totindex_npgood", "gr_cpi", "ln_rimp", "ln_rexp", "ln_rinv", "ln_rgdp", "tariffrate","ffr"];
sDefault.detpolynorder   = 1; % 0 = constant, 1 = constant and linear trend, 2 = ... ) 
sDefault.Exovar          = ""; % "" (empty) or an exogenous variable of tData
sDefault.shockname       = "tariffrate";
sDefault.vShockPos       = find(contains(sDefault.vVariables, sDefault.shockname));
sDefault.lags            = 4;
sDefault.vSample         = ["1990-01-01", "2024-10-01"];
sDefault.missingzero     = false;
sDefault.estimator.name  = "bvar_inversewishart";
sDefault.estimator.nd    = 20000;
sDefault.estimator.burn  = 0; % no MCMC algorithm, so no burn-in needed
sDefault.estimator.pct   = vPercentiles; % middle value is the point estimate
sDefault.estimator.H     = 21;
sDefault.H               = 21;
sDefault.name            = "default";
sDefault.saveIRF         = 0;
sDefault.saveshock       = 0;
sDefault.scalingfactor   = 1;

% Default counterfactual setup
sDefaultcf.name         = "default";
sDefaultcf.target       = "targetvar"; 
sDefaultcf.pct          = vPercentiles; 
sDefaultcf.weighting    = "quadratic";  % uniform, linear, quadratic (for counterfactual)
sDefaultcf.H            = sDefault.H;

% Parallel pool: opened by the estimation stages (posterior draws use per-draw
% Threefry substreams, so results do not depend on the number of workers)
openpool = @() evalin('base', "if isempty(gcp('nocreate')); parpool('local', n_workers); end");

% Helpers to save / load estimation results (one .mat per specification)
savevar = @(name, s) save(char(pathResults + "var_" + name + ".mat"), 's');
loadvar = @(name) getfield(load(char(pathResults + "var_" + name + ".mat"), 's'), 's');
havevar = @(name) resume && isfile(char(pathResults + "var_" + name + ".mat"));
savecf  = @(name, s) save(char(pathResults + "cf_" + name + ".mat"), 's');
loadcf  = @(name) getfield(load(char(pathResults + "cf_" + name + ".mat"), 's'), 's');
havecf  = @(name) resume && isfile(char(pathResults + "cf_" + name + ".mat"));
