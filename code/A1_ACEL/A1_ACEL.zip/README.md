# From-scratch MATLAB replication: ACEL VAR(4), VAR(8) and VAR(12)

This package reruns the analysis by Del Col from the included ACEL source data. It does not depend on the previously saved IRF result files. It estimates the VARs, bootstraps the VAR IRFs, estimates the matched DSGE models, computes the requested plots, and saves the results.

The package launcher and the model IRF mapping were tested with MATLAB R2026a on Windows. The original ACEL code is older; the included copy has a small compatibility adjustment in `Source/ACEL_2005_NBER_WP_Replication_Package/acelcode/modirf.m`.

## What is included

```text
MATLAB_Replication_Package/
|-- README.md
|-- RUN_FROM_SCRATCH.m        Run the complete workflow
|-- RERUN_ACEL_ESTIMATION.m   Estimate VARs and matched DSGE models
|-- RUN_REPLICATION.m         Plot already generated result files
|-- Data/                     Initially empty; receives results_lag_*.mat
|-- Output/                   Receives the IRF PDF figures
|-- Scripts/                  Thesis plot scripts
`-- Source/
    `-- ACEL_2005_NBER_WP_Replication_Package/
        |-- acelcode/         ACEL MATLAB code and original data
        |-- AndersenMoore/    Model solution routines
        `-- code2/            Model solution routines
```

The original spreadsheets, CSVs and other input data are included under `Source/.../acelcode`. Do not remove them.

## Requirements

- MATLAB R2026a (the version installed on the author's computer and used for the launcher test).
- Keep the extracted folder together; do not move files out of `Source`, `Scripts`, or `Data`.
- The full run is computationally intensive. Allow several hours, keep MATLAB running, and ensure the computer does not go to sleep.

## Run everything from scratch

1. Extract the complete ZIP to a writable folder.
2. Start MATLAB.
3. In MATLAB, open the extracted `MATLAB_Replication_Package` folder (or use `cd` in the Command Window).
4. Open and run `RUN_FROM_SCRATCH.m`.

Command Window alternative:

```matlab
cd("C:\path\to\MATLAB_Replication_Package")
run("RUN_FROM_SCRATCH.m")
```

Replace the example path with where you extracted the package.

The launcher performs these steps for p=4, p=8 and p=12:

1. Loads the original ACEL data from the included spreadsheets and CSV files.
2. Estimates each VAR and calculates 20-quarter impulse responses.
3. Runs 1,000 bootstrap replications for VAR IRF uncertainty.
4. Estimates the DSGE parameters by matching the model IRFs to that lag-order's VAR IRFs.
5. Computes model standard errors and the implied price-stickiness measures.
6. Saves a complete `results_lag_p.mat` file for each lag order in `Data`.
7. Creates the PDF IRF figures in `Output`.

The standard full-run settings are 1,000 bootstrap draws, up to 1,000 optimization iterations, and model standard errors enabled. These match the thesis workflow. The legacy estimation can print matrix-conditioning warnings. The p=8 and p=12 VARs can also print `VAR Explosive` warnings when the estimated VAR has roots outside the unit circle; the legacy ACEL routine still computes responses, but record this warning and inspect the resulting estimates rather than silently dismissing it. The run is complete only if MATLAB reaches the final “All requested lag orders have completed successfully” and “Replication completed” messages.

## Where to find the results

After a successful run:

```text
Data/results_lag_4.mat
Data/results_lag_8.mat
Data/results_lag_12.mat
```

The IRF PDFs are organized by shock:

```text
Output/
|-- VAR_IRFs_Long_Lag_Progressively_Plots_4_8_12/
|-- VAR_IRFs_Long_Lag_CI_PE_4_8_12_Plots/
|-- DSGE_IRFs_Long_Lag_Progressively_Plots_4_8_12/
`-- DSGE_IRFs_with_VARs_CI_Plots/
```

Each folder contains subfolders for the monetary-policy, neutral-technology, and embodied-technology shocks. The progressive VAR and DSGE figures include comparisons up through p=4, p=8 and p=12.

## Re-plot without re-estimating

After a successful estimation, you can rerun only the figure generation by opening/running `RUN_REPLICATION.m`. It uses the `.mat` files in `Data`; it does not re-estimate the VARs or DSGE models.

## Optional short pipeline test

To check that the source data import, VAR bootstrap and DSGE fitting code start correctly without waiting for the full run, execute this from the MATLAB Command Window:

```matlab
RERUN_ACEL_ESTIMATION(4, 2, 1, true, false)
```

This test runs only VAR(4), uses two bootstrap draws and one optimizer iteration, and skips standard errors. Its estimates are deliberately incomplete and are **not** thesis results. It overwrites `Data/results_lag_4.mat`; run `RUN_FROM_SCRATCH.m` with defaults afterwards to create the full results.

## Important replication notes

- The full launcher starts from the original observations; it does not read precomputed VAR/DSGE `.mat` results.
- `RERUN_ACEL_ESTIMATION` creates temporary lag-specific copies of `main.m` and deletes them after successful completion. The original source `main.m` is not edited.
- The ACEL code writes intermediate files (for example `estimate.m` and bootstrap MAT files) into the source `acelcode` folder while it runs.
- Re-running the full launcher overwrites the three result MAT files and regenerates the PDFs.
- The included common-sample VAR-alignment analysis is not part of this package's baseline run. This package reproduces the baseline thesis ACEL VAR(4), VAR(8) and VAR(12) results.

## Troubleshooting

**“Missing result file” when running `RUN_REPLICATION.m`**  
That script only plots existing results. Run `RUN_FROM_SCRATCH.m` first.

**A file or function cannot be found**  
Confirm that the ZIP was fully extracted and the original data under `Source/.../acelcode` are present. Do not run only a copied script without the rest of the folder.

**The run stops with a MATLAB error**  
Keep the full error text and note which lag order was running. A lag is complete only when its `Data/results_lag_p.mat` file is written and MATLAB reports that it was saved.
