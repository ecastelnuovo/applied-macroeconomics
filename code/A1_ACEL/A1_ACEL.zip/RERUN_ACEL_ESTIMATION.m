function RERUN_ACEL_ESTIMATION(lags, ndraws, max_iterations, estimate_model, compute_standard_errors)
% Re-estimate the VAR and DSGE models from source data for each lag order.
%
% Defaults reproduce the thesis workflow. Optional arguments can be used
% for short pipeline checks, e.g. RERUN_ACEL_ESTIMATION(4,2,1,true,false).

if nargin < 1 || isempty(lags)
    lags = [4 8 12];
end
if nargin < 2 || isempty(ndraws)
    ndraws = 1000;
end
if nargin < 3 || isempty(max_iterations)
    max_iterations = 1000;
end
if nargin < 4 || isempty(estimate_model)
    estimate_model = true;
end
if nargin < 5 || isempty(compute_standard_errors)
    compute_standard_errors = true;
end

validateattributes(lags, {'numeric'}, {'vector','integer','positive'});
validateattributes(ndraws, {'numeric'}, {'scalar','integer','positive'});
validateattributes(max_iterations, {'numeric'}, {'scalar','integer','positive'});
validateattributes(estimate_model, {'logical','numeric'}, {'scalar'});
validateattributes(compute_standard_errors, {'logical','numeric'}, {'scalar'});
lags = lags(:)';

package_root = fileparts(mfilename('fullpath'));
acel_root = fullfile(package_root, 'Source', ...
    'ACEL_2005_NBER_WP_Replication_Package');
acel_code = fullfile(acel_root, 'acelcode');
output_dir = fullfile(package_root, 'Data');

if ~isfile(fullfile(acel_code, 'main.m'))
    error('ACEL source is incomplete. Expected main.m under %s.', acel_code);
end
if ~exist(output_dir, 'dir')
    mkdir(output_dir);
end

addpath(genpath(acel_root));
previous_dir = pwd;
restore_dir = onCleanup(@() cd(previous_dir));
cd(acel_code);

original_main = fullfile(acel_code, 'main.m');
for i = 1:numel(lags)
    p = lags(i);
    result_file = fullfile(output_dir, sprintf('results_lag_%d.mat', p));
    if isfile(result_file)
        delete(result_file);
    end
    if logical(estimate_model)
        model_status = 'enabled';
    else
        model_status = 'disabled';
    end
    fprintf('\n==================================================\n');
    fprintf('Re-estimating ACEL using VAR(%d)\n', p);
    fprintf('Bootstrap draws: %d; DSGE estimation: %s\n', ...
        ndraws, model_status);
    fprintf('==================================================\n');

    text = fileread(original_main);
    text = replace_setting(text, 'vver', '1');
    text = replace_setting(text, 'estvar', '1');
    text = replace_setting(text, 'nlags', num2str(p));
    text = replace_setting(text, 'imp', '1');
    text = replace_setting(text, 'ndraws', num2str(ndraws));
    text = replace_setting(text, 'mimp', num2str(double(logical(estimate_model))));
    text = replace_setting(text, 'estimatemodel', num2str(double(logical(estimate_model))));
    text = replace_setting(text, 'firmspecific', num2str(double(logical(estimate_model))));
    text = replace_setting(text, 'maxx', num2str(max_iterations));
    text = replace_setting(text, 'stderr', ...
        num2str(double(logical(compute_standard_errors && estimate_model))));

    save_path = strrep(result_file, '\', '/');
    save_path = strrep(save_path, '''', '''''');
    save_line = sprintf('\nsave(''%s'', ''-v7.3'');\n', save_path);
    temp_main = fullfile(acel_code, sprintf('replication_main_lag_%d.m', p));

    fid = fopen(temp_main, 'w');
    if fid == -1
        error('Could not create temporary main script: %s', temp_main);
    end
    close_temp = onCleanup(@() fclose(fid));
    fwrite(fid, [text save_line], 'char');
    clear close_temp;

    % The original ACEL main script starts with "clear all". Run it in the
    % base workspace so it cannot clear this function's loop and paths.
    command = sprintf('run(''%s'')', strrep(temp_main, '''', ''''''));
    evalin('base', command);

    delete(temp_main);
    fprintf('Saved fresh VAR(%d) and DSGE results to %s\n', p, ...
        result_file);
end

fprintf('\nAll requested lag orders have completed successfully.\n');
fprintf('Generated result files are in %s\n', output_dir);
end

function text = replace_setting(text, name, value)
pattern = ['(?m)^' name '[ \t]*=[^\r\n]*'];
replacement = sprintf('%s = %s;', name, value);
matches = regexp(text, pattern, 'match');
count = numel(matches);
if count ~= 1
    error('Expected exactly one active %s setting in ACEL main.m; found %d.', ...
        name, count);
end
text = regexprep(text, pattern, replacement, 'once');
end
