This folder starts empty in the from-scratch replication package.
RUN_REPLICATION.m writes the thesis IRF PDF figures into subfolders here
after the three fresh result_lag_*.mat files have been generated.
