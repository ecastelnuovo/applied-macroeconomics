This folder starts empty in the from-scratch replication package.
RERUN_ACEL_ESTIMATION.m writes results_lag_4.mat, results_lag_8.mat,
and results_lag_12.mat here after estimating each VAR and DSGE model.
