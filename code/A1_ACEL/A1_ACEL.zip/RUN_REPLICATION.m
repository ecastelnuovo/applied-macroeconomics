%% MATLAB_Replication_Package entry point
% Run this file from MATLAB.
% It uses the three saved result files included in Data\.

clear; close all; clc;

package_root = fileparts(mfilename('fullpath'));

required = {'results_lag_4.mat', 'results_lag_8.mat', 'results_lag_12.mat'};
for i = 1:numel(required)
    filename = fullfile(package_root, 'Data', required{i});
    if ~isfile(filename)
        error(['Missing result file: %s\nRun RERUN_ACEL_ESTIMATION first, ' ...
            'or run RUN_FROM_SCRATCH.m to re-estimate and plot everything.'], filename);
    end
end

% MATLAB is able to run this package from any current working directory.
scripts_dir = fullfile(package_root, 'Scripts');
addpath(scripts_dir);

run(fullfile(scripts_dir, 'VAR_IRFs_Long_Lag_Progressively_Plots_4_8_12.m'));
run(fullfile(scripts_dir, 'VAR_IRFs_Long_Lag_Comparison_Plots_4_8_12_CI.m'));
run(fullfile(scripts_dir, 'DSGE_IRFs_Long_Lag_Progressively_Plots_4_8_12.m'));
run(fullfile(scripts_dir, 'DSGE_IRFs_with_VARs_CI_IRFs.m'));

fprintf('\nReplication completed.\n');
fprintf('PDF files are in:\n  %s\n', fullfile(package_root, 'Output'));
