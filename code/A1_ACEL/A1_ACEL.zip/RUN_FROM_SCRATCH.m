%% Full from-scratch replication: VAR estimation, bootstrap, DSGE fit and plots
clear; clc; close all;

package_root = fileparts(mfilename('fullpath'));
addpath(package_root);

RERUN_ACEL_ESTIMATION;
run(fullfile(package_root, 'RUN_REPLICATION.m'));
